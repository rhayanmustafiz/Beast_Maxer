
import React, { useEffect, useState } from 'react';
import { ScanHistoryItem } from '../types';
import { getHistory } from '../services/historyService';
import { Clock, ChevronRight, Database } from 'lucide-react';

interface Props {
  onSelect: (age: number) => void;
  onLoadHistory: (item: ScanHistoryItem) => void;
}

const AgeGate: React.FC<Props> = ({ onSelect, onLoadHistory }) => {
  const [ageInput, setAgeInput] = useState('');
  const [history, setHistory] = useState<ScanHistoryItem[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      const data = await getHistory();
      setHistory(data);
      setLoadingHistory(false);
    };
    loadData();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleStart();
  };

  const handleStart = () => {
    const age = parseInt(ageInput);
    if (!age || age < 1 || age > 100) return;
    onSelect(age);
  };

  return (
    <div className="max-w-md mx-auto mt-6 md:mt-12 px-6 pb-20">
      {/* Header Image Replacement */}
      <div className="flex justify-center mb-8 relative">
        <div className="absolute inset-0 bg-beast-red/20 blur-3xl rounded-full opacity-20 pointer-events-none"></div>
        <img 
          src="./beast-maker.png" 
          alt="Beast Maker Protocol" 
          className="w-full max-w-[320px] object-contain drop-shadow-[0_0_25px_rgba(220,38,38,0.3)] animate-fade-in"
        />
      </div>

      {/* Changed to div to prevent accidental form submission behavior on some hosts */}
      <div className="bg-beast-card border border-beast-border p-6 md:p-8 relative overflow-hidden flex flex-col gap-6 shadow-2xl rounded-xl z-10">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-beast-red via-transparent to-beast-red opacity-50"></div>
        
        <div>
           <label className="block text-beast-muted text-xs font-mono uppercase mb-2 select-none">Age (Years)</label>
           <input 
             type="number" 
             value={ageInput}
             onChange={(e) => setAgeInput(e.target.value)}
             className="w-full bg-black border border-beast-border p-4 text-3xl font-black text-white focus:border-beast-red focus:outline-none text-center placeholder-gray-800 font-mono rounded-lg transition-colors"
             placeholder="00"
             autoFocus
           />
        </div>

        <button 
          type="button"
          onClick={handleStart}
          disabled={!ageInput || parseInt(ageInput) < 10}
          className="w-full py-4 bg-beast-red text-black font-black uppercase tracking-widest hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all mt-2 rounded-lg shadow-lg shadow-beast-red/20 hover:shadow-beast-red/40"
        >
          Initialize Protocol
        </button>
      </div>
      
      {/* History Section */}
      <div className="mt-10 animate-fade-in">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-bold text-beast-muted uppercase flex items-center gap-2">
            <Clock className="w-3 h-3" /> Recent Scans
          </h3>
          <span className="text-[9px] font-mono text-green-600 flex items-center gap-1">
             <Database className="w-3 h-3" /> BEAST STORAGE ACTIVE
          </span>
        </div>
        
        {loadingHistory ? (
          <div className="text-center text-beast-muted text-xs font-mono py-4">Accessing Storage...</div>
        ) : history.length > 0 ? (
          <div className="space-y-3">
            {history.map((item) => (
              <div 
                key={item.id}
                onClick={() => onLoadHistory(item)}
                className="group flex items-center gap-4 p-3 bg-black border border-beast-border hover:border-beast-red cursor-pointer transition-all rounded-lg"
              >
                {item.thumbnail ? (
                  <img src={item.thumbnail} alt="scan" className="w-12 h-12 object-cover border border-white/10 rounded" />
                ) : (
                  <div className="w-12 h-12 bg-beast-border flex items-center justify-center text-[10px] text-gray-500 rounded">NO IMG</div>
                )}
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-bold text-sm">Score: {item.score}</span>
                    <span className="text-[10px] bg-white/10 px-1 rounded text-gray-400">
                      {new Date(item.date).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-[10px] text-beast-muted truncate max-w-[200px]">
                    {item.analysisResult.brutalTruth}
                  </p>
                </div>
                <ChevronRight className="w-4 h-4 text-beast-border group-hover:text-beast-red" />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center p-6 border border-dashed border-beast-border text-beast-muted text-xs rounded-lg">
            No data in Beast Maker Storage yet.
          </div>
        )}
      </div>

      <div className="mt-6 text-center text-[10px] text-beast-muted font-mono uppercase select-none">
        <span className="text-beast-red">*</span> Honest Analysis required
      </div>
    </div>
  );
};

export default AgeGate;
