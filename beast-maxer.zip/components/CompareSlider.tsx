import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Calendar } from 'lucide-react';

interface Props {
  beforeImage: string;
  afterImage: string;
  beforeDate: string;
  afterDate?: string;
  beforeScore: number;
  afterScore: number;
}

const CompareSlider: React.FC<Props> = ({ 
  beforeImage, 
  afterImage, 
  beforeDate, 
  beforeScore, 
  afterScore 
}) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMove = (event: MouseEvent | TouchEvent) => {
    if (!containerRef.current) return;

    const containerRect = containerRef.current.getBoundingClientRect();
    const clientX = 'touches' in event ? event.touches[0].clientX : event.clientX;
    
    let position = ((clientX - containerRect.left) / containerRect.width) * 100;
    position = Math.max(0, Math.min(100, position));
    
    setSliderPosition(position);
  };

  const handleMouseDown = () => setIsDragging(true);
  const handleMouseUp = () => setIsDragging(false);

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMove);
      window.addEventListener('touchmove', handleMove);
      window.addEventListener('mouseup', handleMouseUp);
      window.addEventListener('touchend', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('touchmove', handleMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchend', handleMouseUp);
    };
  }, [isDragging]);

  const formatDate = (isoString: string) => {
    return new Date(isoString).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  };

  const scoreDiff = afterScore - beforeScore;

  return (
    <div className="bg-dark-card rounded-2xl border border-white/10 overflow-hidden shadow-xl select-none">
      <div className="p-4 border-b border-white/10 flex items-center justify-between bg-dark-bg/50">
        <h3 className="font-bold text-white flex items-center gap-2">
          <Calendar className="w-4 h-4 text-glow-400" /> Progress Check
        </h3>
        <div className={`px-3 py-1 rounded-full text-xs font-bold ${scoreDiff >= 0 ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
          ABI {scoreDiff > 0 ? '+' : ''}{scoreDiff}
        </div>
      </div>

      <div 
        ref={containerRef}
        className="relative w-full h-80 sm:h-96 cursor-col-resize group"
        onMouseDown={handleMouseDown}
        onTouchStart={handleMouseDown}
      >
        {/* Before Image (Background) */}
        <img 
          src={beforeImage} 
          alt="Before" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        
        {/* After Image (Foreground - Clipped) */}
        <div 
          className="absolute inset-0 w-full h-full overflow-hidden"
          style={{ width: `${sliderPosition}%` }}
        >
          <img 
            src={afterImage} 
            alt="After" 
            className="absolute top-0 left-0 w-[100vw] max-w-none h-full object-cover"
            style={{ width: containerRef.current?.offsetWidth }}
          />
        </div>

        {/* Labels */}
        <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium text-white pointer-events-none z-10">
          Previous ({formatDate(beforeDate)}) <span className="text-glow-300 ml-1">{beforeScore}</span>
        </div>
        <div className="absolute top-4 right-4 bg-glow-600/80 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium text-white pointer-events-none z-10">
          Today <span className="text-white ml-1 font-bold">{afterScore}</span>
        </div>

        {/* Slider Handle */}
        <div 
          className="absolute top-0 bottom-0 w-1 bg-white cursor-col-resize z-20 shadow-[0_0_10px_rgba(0,0,0,0.5)]"
          style={{ left: `${sliderPosition}%` }}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center">
             <div className="flex gap-0.5">
               <ChevronLeft className="w-3 h-3 text-glow-900" />
               <ChevronRight className="w-3 h-3 text-glow-900" />
             </div>
          </div>
        </div>
      </div>
      
      <div className="p-3 bg-dark-bg/80 text-center text-xs text-gray-400 border-t border-white/5">
        Drag slider to compare
      </div>
    </div>
  );
};

export default CompareSlider;
