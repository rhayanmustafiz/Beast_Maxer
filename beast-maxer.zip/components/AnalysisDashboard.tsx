
import React from 'react';
import { AnalysisResult, ScanHistoryItem } from '../types';
import { RadialBarChart, RadialBar, Legend, ResponsiveContainer, Tooltip } from 'recharts';
import { CheckCircle, AlertCircle, Sparkles, Activity } from 'lucide-react';
import CompareSlider from './CompareSlider';

interface Props {
  result: AnalysisResult;
  currentImage?: string; // We need the current image for the slider
  previousScan?: ScanHistoryItem | null; // Passed from parent
}

const AnalysisDashboard: React.FC<Props> = ({ result, currentImage, previousScan }) => {
  // Format metrics for Recharts - using dummy data derived from overall score since specific metrics aren't in this version of AnalysisResult
  const chartData = [
    { name: 'Current', uv: result.overallScore * 10, fill: '#8b5cf6' },
    { name: 'Potential', uv: result.potentialScore * 10, fill: '#a78bfa' },
    { name: 'Jawline', uv: result.overallScore * 9, fill: '#c4b5fd' }, // Estimation
    { name: 'Skin', uv: result.overallScore * 8, fill: '#7c3aed' },   // Estimation
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Comparison Slider (if history exists) */}
      {previousScan && currentImage && (
        <div className="mb-8 animate-slide-up">
           <CompareSlider 
             beforeImage={previousScan.thumbnail}
             afterImage={currentImage}
             beforeDate={previousScan.date}
             beforeScore={previousScan.score}
             afterScore={result.overallScore * 10}
           />
        </div>
      )}

      {/* ABI Score Card */}
      <div className="bg-gradient-to-br from-glow-900 to-dark-card rounded-3xl p-8 border border-glow-500/20 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-glow-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        
        <div className="flex flex-col md:flex-row items-center gap-8 relative z-10">
          <div className="flex-1 text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-glow-500/20 border border-glow-500/30 text-glow-200 text-xs font-bold uppercase tracking-wider mb-4">
              <Activity className="w-3 h-3" /> Core Metric
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-2">
              {result.overallScore * 10}<span className="text-2xl text-glow-300">/100</span>
            </h2>
            <p className="text-xl text-glow-100 font-medium mb-2">Aesthetic Balance Index (ABI)</p>
            <p className="text-sm text-glow-200/80 leading-relaxed max-w-md">
              {result.brutalTruth}
            </p>
          </div>
          
          <div className="w-full md:w-1/3 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RadialBarChart cx="50%" cy="50%" innerRadius="10%" outerRadius="80%" barSize={10} data={chartData}>
                <RadialBar
                  label={{ position: 'insideStart', fill: '#fff' }}
                  background
                  dataKey="uv"
                />
                <Legend iconSize={10} layout="vertical" verticalAlign="middle" wrapperStyle={{color: "#fff"}} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff' }}
                />
              </RadialBarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Strengths */}
        <div className="bg-dark-card rounded-2xl p-6 border border-white/5">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-green-500/20 rounded-lg">
              <Sparkles className="w-6 h-6 text-green-400" />
            </div>
            <h3 className="text-xl font-bold text-white">Your Assets</h3>
          </div>
          <ul className="space-y-4">
            {(result.assets || []).map((item, idx) => (
              <li key={idx} className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 shrink-0" />
                <span className="text-gray-300 text-sm">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Improvements */}
        <div className="bg-dark-card rounded-2xl p-6 border border-white/5">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-yellow-500/20 rounded-lg">
              <AlertCircle className="w-6 h-6 text-yellow-400" />
            </div>
            <h3 className="text-xl font-bold text-white">Focus Areas</h3>
          </div>
          <ul className="space-y-4">
            {(result.liabilities || []).map((item, idx) => (
              <li key={idx} className="flex items-start gap-3">
                <div className="w-5 h-5 rounded-full bg-yellow-500/10 flex items-center justify-center shrink-0 mt-0.5 text-xs text-yellow-500 font-bold border border-yellow-500/30">
                  {idx + 1}
                </div>
                <span className="text-gray-300 text-sm">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Deep Dive Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-dark-card p-5 rounded-xl border border-white/5">
          <h4 className="text-gray-400 text-xs font-bold uppercase mb-2">Skin Texture</h4>
          <p className="text-white font-medium">{result.skinAnalysis?.texture || "Analysis Pending"}</p>
        </div>
        <div className="bg-dark-card p-5 rounded-xl border border-white/5">
          <h4 className="text-gray-400 text-xs font-bold uppercase mb-2">Skin Type</h4>
          <p className="text-white font-medium">{result.skinAnalysis?.type || "Unknown"}</p>
        </div>
        <div className="bg-dark-card p-5 rounded-xl border border-white/5">
          <h4 className="text-gray-400 text-xs font-bold uppercase mb-2">Jawline Quality</h4>
          <p className="text-white font-medium">{result.jawlineAnalysis?.quality || "Assessing..."}</p>
        </div>
        <div className="bg-dark-card p-5 rounded-xl border border-white/5">
          <h4 className="text-gray-400 text-xs font-bold uppercase mb-2">Jawline Advice</h4>
          <p className="text-white font-medium">{result.jawlineAnalysis?.advice || "No specific advice."}</p>
        </div>
        <div className="bg-dark-card p-5 rounded-xl border border-white/5 md:col-span-2">
           <h4 className="text-gray-400 text-xs font-bold uppercase mb-2">Key Concerns</h4>
           <div className="flex flex-wrap gap-2">
             {(result.skinAnalysis?.issues || []).map(c => (
               <span key={c} className="px-2 py-1 bg-red-500/10 border border-red-500/20 text-red-300 text-xs rounded-md">
                 {c}
               </span>
             ))}
           </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisDashboard;
