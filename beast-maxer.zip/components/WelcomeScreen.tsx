
import React, { useEffect, useState } from 'react';
import { ChevronRight, Skull, Activity, Zap } from 'lucide-react';

interface Props {
  onStart: () => void;
}

const WelcomeScreen: React.FC<Props> = ({ onStart }) => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    // Trigger animation after mount
    const t = setTimeout(() => setShow(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="fixed inset-0 bg-beast-bg flex items-center justify-start z-50 overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none" />
      <div className={`absolute top-0 right-0 w-2/3 h-full bg-gradient-to-l from-beast-red/5 to-transparent transition-opacity duration-1000 ${show ? 'opacity-100' : 'opacity-0'}`} />

      {/* Main Content Container - Slides from Left */}
      <div className={`relative z-10 w-full max-w-4xl p-8 md:p-20 flex flex-col gap-8 transition-all duration-1000 ease-out transform ${show ? 'translate-x-0 opacity-100' : '-translate-x-full opacity-0'}`}>
        
        {/* Branding - LOGO SECTION */}
        <div className="flex items-center gap-6">
          <div className="w-32 h-32 shrink-0 bg-black rounded-2xl flex items-center justify-center shadow-2xl relative group overflow-hidden">
             {/* Logo Image */}
             <img 
               src="./logo.png" 
               alt="Beast Maxer Logo" 
               className="w-full h-full object-contain relative z-10 group-hover:scale-110 transition-transform duration-500" 
               onError={(e) => {
                 (e.target as HTMLImageElement).style.display = 'none';
                 (e.target as HTMLImageElement).parentElement!.classList.add('border-2', 'border-beast-red');
               }}
             />
             {/* Fallback Icon only if image fails (hidden by default image cover) */}
             <Skull className="w-12 h-12 text-white absolute z-0 opacity-50" />
             
             {/* Glow effect behind logo */}
             <div className="absolute inset-0 bg-beast-red/10 blur-xl group-hover:bg-beast-red/20 transition-colors pointer-events-none"></div>
          </div>
          <div className="h-24 w-1 bg-gradient-to-b from-beast-gold to-beast-red opacity-50"></div>
          <div className="flex flex-col justify-center">
            <span className="text-beast-gold font-mono text-sm tracking-[0.3em] uppercase mb-1">System Online</span>
            <span className="text-beast-muted text-xs font-mono flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              Owned by <span className="text-emerald-500 font-bold ml-1">Rhayan</span> & <span className="text-emerald-500 font-bold">Ahasan</span>
            </span>
          </div>
        </div>

        {/* Big Headline */}
        <div>
          <h1 className="text-7xl md:text-9xl font-black text-beast-text leading-[0.9] uppercase tracking-tighter">
            Welcome <br/>
            To <span className="text-transparent bg-clip-text bg-gradient-to-r from-beast-gold to-beast-red">Beast</span>
          </h1>
          <h1 className="text-7xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-r from-beast-text to-beast-muted/20 leading-[0.9] uppercase tracking-tighter">
            Maxer
          </h1>
        </div>

        {/* Subtitle / Mission */}
        <p className="text-lg md:text-2xl text-beast-muted border-l-4 border-beast-red pl-6 py-4 max-w-2xl leading-relaxed">
          The world's most advanced biometric analysis and self-improvement protocol. 
          <span className="block mt-2 text-beast-text font-bold">Optimize your aesthetics. Maximize your potential.</span>
        </p>

        {/* CTA Button */}
        <div className="mt-8">
          <button 
            onClick={onStart}
            className="group px-12 py-6 bg-beast-red text-white font-black text-xl uppercase tracking-[0.2em] shadow-[0_0_40px_rgba(220,38,38,0.4)] hover:shadow-[0_0_60px_rgba(220,38,38,0.6)] hover:bg-red-600 transition-all flex items-center gap-6 clip-path-polygon"
          >
            Initiate Scan
            <ChevronRight className="w-8 h-8 group-hover:translate-x-3 transition-transform" />
          </button>
        </div>

        {/* Footer Metrics */}
        <div className="flex gap-12 mt-12 opacity-60">
           <div className="flex items-center gap-3">
             <Activity className="w-5 h-5 text-beast-gold" />
             <span className="text-xs font-mono text-beast-muted tracking-widest">FACIAL GEOMETRY</span>
           </div>
           <div className="flex items-center gap-3">
             <Zap className="w-5 h-5 text-beast-red" />
             <span className="text-xs font-mono text-beast-muted tracking-widest">SKIN INTEGRITY</span>
           </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomeScreen;
