
import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send, X, Bot, User, Gamepad2, Sparkles } from 'lucide-react';
import { ChatMessage } from '../types';
import { sendMessageToChat } from '../services/geminiService';

const BeastChat: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "System Online. Begin the protocol. Ask me regarding lookmaxxing advice, or type 'Game' to play a quiz to test your knowledge." }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  // State to track if the last message was a quiz question
  const [showQuizOptions, setShowQuizOptions] = useState(false);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
    
    // Check if the latest model message looks like a quiz question
    const lastMsg = messages[messages.length - 1];
    if (lastMsg && lastMsg.role === 'model') {
       const text = lastMsg.text;
       // Heuristic: Check for common Multiple Choice patterns
       const hasOptions = (text.includes("A)") || text.includes("A.")) && 
                          (text.includes("B)") || text.includes("B."));
       
       // Ensure we don't show options if it's a summary/result/correction log
       // Common indicators of results/explanations:
       const isResult = text.includes("Score:") || 
                        text.includes("Rank:") || 
                        text.includes("Explanation:") ||
                        text.includes("Correct Answer:");

       setShowQuizOptions(hasOptions && !isResult);
    } else {
       setShowQuizOptions(false);
    }

  }, [messages, isOpen]);

  const handleSend = async (msgText: string = input) => {
    if (!msgText.trim() || loading) return;

    const userMsg = msgText;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);
    setShowQuizOptions(false); // Hide options immediately after user answers

    try {
      const response = await sendMessageToChat(userMsg);
      setMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (e: any) {
      console.error("Chat Error", e);
      let errorText = "Connection error. Try again.";
      
      // Handle the specific error thrown when chatSession is null
      if (e.message && (e.message.includes("Chat not initialized") || e.message.includes("Analysis data may be lost"))) {
        errorText = "Session lost. Please refresh the page or complete a scan to restart.";
      } else if (e.message && (e.message.includes("API Key") || e.message.includes("403"))) {
        errorText = "System Error: API Key missing or invalid.";
      }
      
      setMessages(prev => [...prev, { role: 'model', text: errorText }]);
    } finally {
      setLoading(false);
    }
  };

  const startQuiz = () => {
    handleSend("Let's play a quiz game. Ask me a multiple-choice question about facial aesthetics, health, or math. Give me 4 options: A, B, C, D.");
  };

  return (
    <>
      {/* Floating Button - High Z-Index */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-6 z-[100] p-4 rounded-full shadow-2xl transition-all hover:scale-105 ${
          isOpen ? 'bg-black border border-beast-red text-beast-red' : 'bg-beast-red text-black'
        }`}
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
      </button>

      {/* Chat Window - High Z-Index */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 w-[85vw] max-w-[360px] h-[500px] bg-black border border-beast-border rounded-xl shadow-2xl z-[100] flex flex-col overflow-hidden animate-slide-up">
          {/* Header */}
          <div className="bg-beast-card p-3 border-b border-beast-border flex items-center justify-between">
            <div className="flex items-center gap-2">
               <Bot className="w-5 h-5 text-beast-red" />
               <span className="font-bold text-white uppercase text-sm tracking-wider">Beast Bot</span>
            </div>
            {/* Game Mode Button */}
            <button 
              onClick={startQuiz}
              disabled={loading}
              className="flex items-center gap-1 px-2 py-1 rounded bg-beast-red/10 text-beast-red text-[10px] font-bold uppercase hover:bg-beast-red hover:text-white transition-colors border border-beast-red/30"
            >
              <Gamepad2 className="w-3 h-3" />
              Game Mode
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={scrollRef}>
            {messages.map((m, i) => (
              <div key={i} className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {m.role === 'model' && (
                  <div className="w-8 h-8 rounded-full bg-beast-red/10 flex items-center justify-center shrink-0 border border-beast-red/30">
                    <Bot className="w-4 h-4 text-beast-red" />
                  </div>
                )}
                <div className={`p-3 rounded-lg text-sm max-w-[80%] whitespace-pre-wrap ${
                  m.role === 'user' 
                    ? 'bg-beast-red text-black font-medium' 
                    : 'bg-beast-card border border-beast-border text-gray-300'
                }`}>
                  {m.text}
                </div>
                {m.role === 'user' && (
                  <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center shrink-0">
                    <User className="w-4 h-4 text-gray-400" />
                  </div>
                )}
              </div>
            ))}
            {loading && (
              <div className="flex gap-2 items-center text-beast-muted text-xs ml-10">
                <div className="w-2 h-2 bg-beast-red rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-beast-red rounded-full animate-bounce delay-75"></div>
                <div className="w-2 h-2 bg-beast-red rounded-full animate-bounce delay-150"></div>
              </div>
            )}
          </div>
          
          {/* Quiz Quick Options (Conditional) */}
          {showQuizOptions && !loading && (
            <div className="px-3 pb-2 flex gap-2 justify-center animate-fade-in">
               {['A', 'B', 'C', 'D'].map(opt => (
                 <button
                   key={opt}
                   onClick={() => handleSend(opt)}
                   className="w-10 h-10 rounded-full bg-beast-card border border-beast-border hover:bg-beast-red hover:text-black hover:border-beast-red text-white font-bold transition-all shadow-lg flex items-center justify-center"
                 >
                   {opt}
                 </button>
               ))}
            </div>
          )}

          {/* Input */}
          <div className="p-3 bg-beast-card border-t border-beast-border flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask how to fix..."
              className="flex-1 bg-black border border-beast-border rounded px-3 py-2 text-sm text-white focus:border-beast-red focus:outline-none"
            />
            <button 
              type="button"
              onClick={() => handleSend()}
              disabled={loading || !input.trim()}
              className="p-2 bg-beast-red text-black rounded hover:bg-red-600 disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default BeastChat;
