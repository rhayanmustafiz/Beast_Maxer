
import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Play, Pause, SkipForward, CheckCircle2, Lock, Flame, RefreshCcw, Video, Droplet, Trophy, X, Bell, Plus, Trash2, Clock, Settings } from 'lucide-react';
import { Exercise } from '../types';
import { playClickSound, playSuccessSound } from '../services/audioService';
import { requestNotificationPermission, getPermissionStatus, sendNotification } from '../services/notificationService';

interface Props {
  onBack: () => void;
}

// 1. DATA STRUCTURE
const JAWLINE_EXERCISES: Exercise[] = [
  {
    id: 1,
    name: "Side-to-Side Turns",
    duration: 30,
    video_url: "side_to_side.mp4",
    instructions: "Slowly turn your head to the right, hold for 2s, then turn left. Feel the stretch in your neck."
  },
  {
    id: 2,
    name: "Up & Down Nod",
    duration: 30,
    video_url: "placeholder_nod.mp4",
    instructions: "Look up at the ceiling, stretching your neck. Then slowly look down towards your chest."
  },
  {
    id: 3,
    name: "The Lion",
    duration: 20,
    video_url: "placeholder_lion.mp4",
    instructions: "Open your mouth wide and stick your tongue out as far as possible. Hold tension."
  },
  {
    id: 4,
    name: "Neck Lift",
    duration: 30,
    video_url: "placeholder_lift.mp4",
    instructions: "Lie on your back (or lean back). Lift your head a few inches off the ground, hold, and lower."
  },
  {
    id: 5,
    name: "Jaw Jut",
    duration: 25,
    video_url: "placeholder_jut.mp4",
    instructions: "Push your lower jaw forward until you feel a stretch under the chin. Hold and relax."
  },
  {
    id: 6,
    name: "Tongue Press (Mewing)",
    duration: 40,
    video_url: "placeholder_mew.mp4",
    instructions: "Press your entire tongue against the roof of your mouth. Hold the pressure hard."
  },
  {
    id: 7,
    name: "Chin Tucks",
    duration: 25,
    video_url: "placeholder_tuck.mp4",
    instructions: "Pull your head straight back (create a double chin) to align your spine."
  },
  {
    id: 8,
    name: "Lower Jaw Push",
    duration: 20,
    video_url: "placeholder_lower_push.mp4",
    instructions: "Push your lower jaw forward and slightly up with your mouth closed. Hold tension."
  },
  {
    id: 9,
    name: "Fish Face",
    duration: 30,
    video_url: "placeholder_fish_face.mp4",
    instructions: "Suck in your cheeks and lips to make a fish face. Hold and try to smile."
  },
  {
    id: 10,
    name: "Cheek Puff",
    duration: 25,
    video_url: "placeholder_cheek_puff.mp4",
    instructions: "Fill your mouth with air. Push the air to the right cheek, hold, then left cheek."
  },
  {
    id: 11,
    name: "V-Shape Pull",
    duration: 30,
    video_url: "placeholder_v_pull.mp4",
    instructions: "Place thumbs under your chin and swipe along the jawline up to your ears."
  },
  {
    id: 12,
    name: "Tongue Circles",
    duration: 40,
    video_url: "placeholder_tongue_circles.mp4",
    instructions: "With mouth closed, rotate your tongue in a large circle around the outside of your teeth."
  },
  {
    id: 13,
    name: "Smile Stretch",
    duration: 20,
    video_url: "placeholder_smile_stretch.mp4",
    instructions: "Smile as wide as you can without opening your mouth. Feel the cheek muscles engage."
  }
];

// Pre-calculate random bubble positions for consistency
const BUBBLES = Array.from({ length: 15 }).map((_, i) => ({
  id: i,
  left: `${Math.random() * 80 + 10}%`,
  size: Math.random() * 8 + 4, // 4px to 12px
  delay: Math.random() * 5,
  duration: Math.random() * 3 + 3, // 3s to 6s
}));

// --- CSS ANIMATION COMPONENTS ---
const HeadTurnVisual = () => (
  <div className="relative w-full h-full flex items-center justify-center bg-zinc-800">
    <div className="relative perspective-[1000px]">
      {/* Head Group */}
      <div className="w-32 h-40 bg-zinc-200 rounded-[3rem] relative animate-head-turn shadow-2xl border-4 border-zinc-300 flex flex-col items-center justify-center">
        {/* Hair Hint */}
        <div className="absolute -top-2 w-28 h-8 bg-zinc-800 rounded-t-full"></div>
        
        {/* Eyes Container */}
        <div className="flex gap-8 mb-4 mt-2">
          <div className="w-3 h-3 bg-zinc-900 rounded-full"></div>
          <div className="w-3 h-3 bg-zinc-900 rounded-full"></div>
        </div>
        {/* Nose */}
        <div className="w-3 h-8 bg-zinc-300 rounded-full mb-4 shadow-inner"></div>
        {/* Mouth */}
        <div className="w-8 h-1.5 bg-zinc-900 rounded-full"></div>
        
        {/* Ears (Absolute to head) */}
        <div className="absolute -left-3 top-16 w-3 h-8 bg-zinc-300 rounded-l-lg border-l-2 border-zinc-400"></div>
        <div className="absolute -right-3 top-16 w-3 h-8 bg-zinc-300 rounded-r-lg border-r-2 border-zinc-400"></div>
      </div>
      
      {/* Neck */}
      <div className="w-16 h-12 bg-zinc-300 mx-auto -mt-4 rounded-b-lg relative -z-10"></div>
      {/* Shoulders */}
      <div className="w-48 h-8 bg-zinc-700 mx-auto rounded-t-3xl -mt-2"></div>
    </div>
    
    <style>{`
      @keyframes headTurn {
        0% { transform: rotateY(0deg); }
        20% { transform: rotateY(-35deg); } /* Look Left */
        40% { transform: rotateY(-35deg); } /* Hold */
        50% { transform: rotateY(0deg); }   /* Center */
        70% { transform: rotateY(35deg); }  /* Look Right */
        90% { transform: rotateY(35deg); }  /* Hold */
        100% { transform: rotateY(0deg); }
      }
      .animate-head-turn {
        animation: headTurn 4s ease-in-out infinite;
        transform-style: preserve-3d;
      }
    `}</style>
  </div>
);

const ExerciseProtocol: React.FC<Props> = ({ onBack }) => {
  const [view, setView] = useState<'PLAN' | 'WORKOUT' | 'COMPLETE'>('PLAN');
  const [activeTab, setActiveTab] = useState<'EXERCISES' | 'WATER'>('EXERCISES');
  
  const [currentDay, setCurrentDay] = useState(1);
  const [completedDays, setCompletedDays] = useState<number[]>([]);

  // WORKOUT STATE
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(JAWLINE_EXERCISES[0].duration);
  const [isPaused, setIsPaused] = useState(false);
  const [videoError, setVideoError] = useState(false);
  
  // WATER TRACKER STATE
  const [waterCount, setWaterCount] = useState(0);
  const [isDropping, setIsDropping] = useState(false);
  const [showWaterSuccess, setShowWaterSuccess] = useState(false);
  
  // NOTIFICATION STATE
  const [showReminders, setShowReminders] = useState(false);
  const [reminders, setReminders] = useState<string[]>([]);
  const [newTime, setNewTime] = useState("");
  const [permStatus, setPermStatus] = useState<NotificationPermission>("default");

  const timerRef = useRef<any>(null);
  const autoAdvanceTimerRef = useRef<any>(null);

  // --- LOCAL STORAGE FOR PROGRESS ---
  useEffect(() => {
    const saved = localStorage.getItem('beast_exercise_progress');
    if (saved) {
      const data = JSON.parse(saved);
      setCurrentDay(data.currentDay || 1);
      setCompletedDays(data.completedDays || []);
    }
    
    const savedWater = localStorage.getItem('beast_water_count');
    if (savedWater) {
      const count = parseInt(savedWater);
      setWaterCount(count >= 9 ? 0 : count);
    }

    const savedReminders = localStorage.getItem('beast_reminders');
    if (savedReminders) {
      setReminders(JSON.parse(savedReminders));
    }

    setPermStatus(getPermissionStatus());
  }, []);

  const saveProgress = (newCurrent: number, newCompleted: number[]) => {
    localStorage.setItem('beast_exercise_progress', JSON.stringify({
      currentDay: newCurrent,
      completedDays: newCompleted
    }));
  };

  useEffect(() => {
    localStorage.setItem('beast_water_count', waterCount.toString());
  }, [waterCount]);

  useEffect(() => {
    localStorage.setItem('beast_reminders', JSON.stringify(reminders));
  }, [reminders]);

  // --- TIMER LOGIC ---
  useEffect(() => {
    if (view === 'WORKOUT' && !isPaused) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleNextExercise();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [view, isPaused, currentExerciseIndex]);
  
  useEffect(() => {
    if (view === 'COMPLETE') {
      autoAdvanceTimerRef.current = setTimeout(() => {
        setView('PLAN');
      }, 5000);
    }
    return () => {
      if (autoAdvanceTimerRef.current) clearTimeout(autoAdvanceTimerRef.current);
    };
  }, [view]);

  useEffect(() => {
    setVideoError(false);
  }, [currentExerciseIndex]);

  const handleStartDay = () => {
    setCurrentExerciseIndex(0);
    setTimeLeft(JAWLINE_EXERCISES[0].duration);
    setIsPaused(false);
    setView('WORKOUT');
  };

  const handleNextExercise = () => {
    if (currentExerciseIndex < JAWLINE_EXERCISES.length - 1) {
      const nextIndex = currentExerciseIndex + 1;
      setCurrentExerciseIndex(nextIndex);
      setTimeLeft(JAWLINE_EXERCISES[nextIndex].duration);
      playClickSound(); 
    } else {
      finishWorkout();
    }
  };

  const finishWorkout = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    playSuccessSound();
    
    const newCompleted = [...completedDays, currentDay];
    const newCurrent = currentDay + 1;
    
    setCompletedDays(newCompleted);
    setCurrentDay(newCurrent);
    saveProgress(newCurrent, newCompleted);
    
    setView('COMPLETE');
  };

  const handleSkip = () => {
    handleNextExercise();
  };

  const togglePause = () => {
    setIsPaused(!isPaused);
  };

  const handleDrinkWater = () => {
    if (isDropping) return;

    playClickSound();
    
    if (waterCount < 8) {
      setWaterCount(prev => prev + 1);
    } else {
      setIsDropping(true);
      setTimeout(() => {
        setShowWaterSuccess(true);
      }, 800);
    }
  };

  const closeWaterSuccess = () => {
    setShowWaterSuccess(false);
    setWaterCount(0);
    setIsDropping(false);
    playClickSound();
  };

  // --- REMINDERS LOGIC ---
  const handleEnableNotifications = async () => {
    if (!("Notification" in window)) {
      alert("This device/browser does not support system notifications.");
      return;
    }

    if (Notification.permission === 'denied') {
      alert("Notifications are currently blocked by your browser.\n\nPlease go to Settings > Site Settings > Notifications and allow them for this site to receive reminders.");
      setPermStatus('denied');
      return;
    }

    try {
      const granted = await requestNotificationPermission();
      setPermStatus(granted ? 'granted' : 'denied');
      
      if (granted) {
        sendNotification("Notifications Active ✅", "You will now receive hydration reminders.");
      }
    } catch (error) {
      console.error("Failed to request permission:", error);
      alert("Something went wrong requesting permissions. Please try again.");
    }
  };

  const addReminder = () => {
    if (!newTime) return;
    if (!reminders.includes(newTime)) {
      setReminders([...reminders, newTime].sort());
      setNewTime("");
    }
  };

  const removeReminder = (time: string) => {
    setReminders(reminders.filter(t => t !== time));
  };

  // --- RENDER HELPERS ---
  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  // --- VIEWS ---

  if (view === 'WORKOUT') {
    const exercise = JAWLINE_EXERCISES[currentExerciseIndex];
    const progressPercent = ((JAWLINE_EXERCISES[currentExerciseIndex].duration - timeLeft) / JAWLINE_EXERCISES[currentExerciseIndex].duration) * 100;

    return (
      <div className="fixed inset-0 bg-zinc-900 z-[200] flex flex-col text-white animate-fade-in">
        {/* Top Bar */}
        <div className="p-4 flex items-center justify-between border-b border-white/10 bg-zinc-900/50 backdrop-blur-md sticky top-0 z-20">
          <button onClick={() => setView('PLAN')} className="p-2 hover:bg-white/10 rounded-full">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <span className="font-bold text-sm tracking-wider uppercase">Session {currentDay}</span>
          <div className="w-8"></div>
        </div>

        {/* Video Container */}
        <div className="w-full aspect-square md:aspect-video bg-zinc-800 relative flex items-center justify-center overflow-hidden">
          
          {exercise.id === 1 ? (
             // CUSTOM ANIMATION FOR ID 1
             <HeadTurnVisual />
          ) : !videoError ? (
            <video 
              key={exercise.id} 
              src={exercise.video_url}
              autoPlay 
              loop 
              muted 
              playsInline
              className="w-full h-full object-cover"
              onError={() => setVideoError(true)}
            />
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center opacity-30">
               <Video className="w-16 h-16 mb-4 text-white" />
               <span className="font-mono text-xs uppercase tracking-widest">Animation Unavailable</span>
            </div>
          )}
          
          {/* Current Exercise Name Overlay */}
          <div className="absolute bottom-0 left-0 w-full p-4 bg-gradient-to-t from-black/80 to-transparent">
            <h2 className="text-2xl font-black uppercase italic tracking-tighter text-white">{exercise.name}</h2>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col items-center justify-between p-8">
          
          {/* Timer */}
          <div className="flex flex-col items-center justify-center mt-4">
            <div className={`text-7xl font-mono font-bold tracking-tighter tabular-nums transition-colors ${timeLeft <= 5 ? 'text-red-500 animate-pulse' : 'text-white'}`}>
              {formatTime(timeLeft)}
            </div>
            <p className="text-zinc-400 text-sm mt-4 text-center max-w-xs">{exercise.instructions}</p>
          </div>

          {/* Controls */}
          <div className="w-full max-w-md space-y-8">
            {/* Progress Bar (Current Exercise) */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold text-zinc-500 uppercase">
                <span>Exercise {currentExerciseIndex + 1}/{JAWLINE_EXERCISES.length}</span>
                <span>{Math.round(progressPercent)}%</span>
              </div>
              <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-500 transition-all duration-1000 ease-linear"
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex items-center justify-center gap-6">
              <button 
                onClick={togglePause}
                className="w-16 h-16 bg-white text-black rounded-full flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-lg shadow-white/10"
              >
                {isPaused ? <Play className="w-6 h-6 fill-black ml-1" /> : <Pause className="w-6 h-6 fill-black" />}
              </button>
              
              <button 
                onClick={handleSkip}
                className="w-12 h-12 bg-zinc-800 text-white rounded-full flex items-center justify-center hover:bg-zinc-700 active:scale-95 transition-all border border-zinc-700"
              >
                <SkipForward className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (view === 'COMPLETE') {
    return (
      <div className="fixed inset-0 bg-white z-[200] flex flex-col items-center justify-center p-8 animate-fade-in relative">
        <div className="absolute top-0 left-0 w-full h-1 bg-gray-100">
           <div className="h-full bg-black animate-[progress_5s_linear]"></div>
        </div>

        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mb-6 animate-bounce">
          <CheckCircle2 className="w-12 h-12 text-green-600" />
        </div>
        <h2 className="text-3xl font-black uppercase text-black mb-2 text-center">Day {currentDay - 1} Crushed</h2>
        <p className="text-gray-500 text-center mb-8">Jawline structure reinforced.</p>
        <button 
          onClick={() => setView('PLAN')}
          className="px-8 py-3 bg-black text-white font-bold rounded-full hover:scale-105 transition-transform flex items-center gap-2"
        >
          Continue Plan <span className="text-xs font-normal opacity-70">(Auto 5s)</span>
        </button>

        <style>{`
          @keyframes progress {
            from { width: 0%; }
            to { width: 100%; }
          }
        `}</style>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-white z-[200] flex flex-col animate-fade-in text-black overflow-hidden">
      
      {showReminders && (
        <div className="fixed inset-0 z-[250] bg-black/80 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in">
           <div className="bg-white rounded-3xl p-6 max-w-sm w-full relative overflow-hidden shadow-2xl">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-black uppercase text-black flex items-center gap-2">
                   <Bell className="w-6 h-6 text-blue-500" /> Reminders
                </h3>
                <button onClick={() => setShowReminders(false)} className="p-2 hover:bg-gray-100 rounded-full">
                   <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              {permStatus !== 'granted' && (
                <div className={`p-4 rounded-xl mb-6 border ${permStatus === 'denied' ? 'bg-red-50 border-red-100' : 'bg-blue-50 border-blue-100'}`}>
                  <div className="flex items-start gap-3 mb-3">
                    {permStatus === 'denied' ? (
                      <Settings className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                    ) : (
                      <Bell className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                    )}
                    <p className={`text-xs ${permStatus === 'denied' ? 'text-red-700' : 'text-blue-700'}`}>
                      {permStatus === 'denied' 
                        ? "Notifications are blocked. Please allow them in your browser settings to continue."
                        : "Allow notifications to receive hydration alerts directly to your device."}
                    </p>
                  </div>
                  <button 
                    onClick={handleEnableNotifications}
                    className={`w-full py-2 text-white text-xs font-bold uppercase rounded-lg transition-colors ${
                      permStatus === 'denied' 
                        ? 'bg-red-500 hover:bg-red-600' 
                        : 'bg-blue-500 hover:bg-blue-600'
                    }`}
                  >
                    {permStatus === 'denied' ? 'Check Settings' : 'Enable Permissions'}
                  </button>
                </div>
              )}

              <div className="mb-6">
                 <label className="text-xs font-bold text-gray-400 uppercase mb-2 block">Add Time</label>
                 <div className="flex gap-2">
                    <input 
                      type="time" 
                      value={newTime}
                      onChange={(e) => setNewTime(e.target.value)}
                      className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 font-mono text-lg font-bold text-black focus:outline-none focus:border-blue-500"
                    />
                    <button 
                      onClick={addReminder}
                      className="p-3 bg-black text-white rounded-xl hover:bg-gray-800 transition-colors"
                    >
                      <Plus className="w-6 h-6" />
                    </button>
                 </div>
              </div>

              <div className="max-h-[200px] overflow-y-auto space-y-2">
                {reminders.length === 0 ? (
                  <p className="text-center text-gray-400 text-xs italic py-4">No active reminders.</p>
                ) : (
                  reminders.map((time) => (
                    <div key={time} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-100">
                       <div className="flex items-center gap-3">
                         <Clock className="w-4 h-4 text-blue-500" />
                         <span className="font-mono font-bold text-lg">{time}</span>
                       </div>
                       <button onClick={() => removeReminder(time)} className="p-2 text-gray-400 hover:text-red-500 transition-colors">
                          <Trash2 className="w-4 h-4" />
                       </button>
                    </div>
                  ))
                )}
              </div>
           </div>
        </div>
      )}

      {showWaterSuccess && (
        <div className="fixed inset-0 z-[250] bg-black/80 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white rounded-3xl p-8 max-w-sm w-full text-center relative overflow-hidden shadow-2xl transform scale-100 animate-bounce-in">
            <div className="absolute inset-0 bg-gradient-to-b from-blue-50 to-white -z-10"></div>
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Trophy className="w-10 h-10 text-blue-600" />
            </div>
            <h2 className="text-2xl font-black text-black uppercase mb-2 leading-tight">You really done a great thing</h2>
            <p className="text-gray-500 text-sm mb-6">Hydration goal achieved. Your skin and muscles thank you.</p>
            <button 
              onClick={closeWaterSuccess}
              className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-colors"
            >
              Close & Reset
            </button>
          </div>
        </div>
      )}

      <div className="p-4 border-b border-gray-100 bg-white sticky top-0 z-10 shadow-sm flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-black" />
            </button>
            <div>
              <h1 className="text-xl font-black uppercase tracking-tight text-black">Exercise for Perfection</h1>
              <p className="text-xs text-gray-400 font-mono mt-1">JAWLINE & FACIAL STRUCTURE</p>
            </div>
          </div>
          
          {activeTab === 'WATER' && (
            <button 
              onClick={() => setShowReminders(true)}
              className="p-2 bg-blue-50 text-blue-600 rounded-full hover:bg-blue-100 transition-colors"
            >
              <Bell className="w-5 h-5" />
            </button>
          )}
        </div>
        
        <div className="flex bg-gray-100 p-1 rounded-xl">
           <button 
             onClick={() => setActiveTab('EXERCISES')}
             className={`flex-1 py-2 text-xs font-bold uppercase rounded-lg transition-all flex items-center justify-center gap-2 ${activeTab === 'EXERCISES' ? 'bg-black text-white shadow-md' : 'text-gray-500 hover:text-black'}`}
           >
             <Flame className="w-4 h-4" /> Workouts
           </button>
           <button 
             onClick={() => setActiveTab('WATER')}
             className={`flex-1 py-2 text-xs font-bold uppercase rounded-lg transition-all flex items-center justify-center gap-2 ${activeTab === 'WATER' ? 'bg-blue-500 text-white shadow-md' : 'text-gray-500 hover:text-blue-500'}`}
           >
             <Droplet className="w-4 h-4" /> Drink Water
           </button>
        </div>
      </div>

      {activeTab === 'EXERCISES' ? (
        <>
          <div className="p-6 bg-blue-500 text-white">
            <div className="flex items-center gap-2 mb-2 opacity-80">
                <Flame className="w-5 h-5" />
                <span className="text-xs font-bold uppercase tracking-wider">Streak</span>
            </div>
            <div className="text-4xl font-black">{completedDays.length} <span className="text-xl font-normal opacity-70">Days</span></div>
            <p className="text-sm mt-2 opacity-90">Consistency is the only metric that matters.</p>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50 pb-24">
            {Array.from({ length: 30 }).map((_, idx) => {
              const dayNum = idx + 1;
              const isCompleted = completedDays.includes(dayNum);
              const isLocked = dayNum > currentDay && !isCompleted;
              const isCurrent = dayNum === currentDay;

              return (
                <div 
                  key={dayNum}
                  className={`flex items-center justify-between p-5 rounded-xl border transition-all ${
                    isCurrent 
                      ? 'bg-sky-50 border-sky-200 shadow-md transform scale-[1.02]' 
                      : isLocked 
                        ? 'bg-gray-100 border-gray-200 opacity-60' 
                        : 'bg-white border-gray-100'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold ${
                      isCompleted ? 'bg-green-100 text-green-700' : isCurrent ? 'bg-black text-white' : 'bg-gray-200 text-gray-500'
                    }`}>
                      {isCompleted ? <CheckCircle2 className="w-5 h-5" /> : dayNum}
                    </div>
                    <div className="flex flex-col">
                      <span className={`font-bold text-sm ${isLocked ? 'text-gray-400' : 'text-black'}`}>
                        Day {dayNum}
                      </span>
                      <span className="text-xs text-gray-400 font-medium">
                        {isCompleted ? 'Completed' : `${JAWLINE_EXERCISES.length} Exercises • ~${Math.ceil((JAWLINE_EXERCISES.reduce((acc, ex) => acc + ex.duration, 0)) / 60)} Mins`}
                      </span>
                    </div>
                  </div>

                  <div>
                    {isCurrent && !isCompleted && (
                      <button 
                        onClick={handleStartDay}
                        className="px-4 py-2 bg-black text-white text-xs font-bold rounded-lg uppercase hover:bg-gray-800 transition-colors shadow-lg flex items-center gap-2"
                      >
                        Start <Play className="w-3 h-3 fill-white" />
                      </button>
                    )}
                    {isLocked && <Lock className="w-5 h-5 text-gray-300" />}
                    {isCompleted && (
                      <button onClick={handleStartDay} className="p-2 text-gray-400 hover:text-black transition-colors" title="Replay">
                        <RefreshCcw className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center p-6 bg-blue-50/50 relative overflow-hidden">
           
           <div className="absolute inset-0 pointer-events-none overflow-hidden">
             <div className="absolute top-[10%] left-[20%] w-4 h-4 bg-blue-200 rounded-full opacity-50 animate-bounce delay-75"></div>
             <div className="absolute top-[40%] right-[15%] w-6 h-6 bg-blue-200 rounded-full opacity-50 animate-bounce delay-150"></div>
             <div className="absolute bottom-[20%] left-[10%] w-8 h-8 bg-blue-200 rounded-full opacity-50 animate-bounce delay-300"></div>
           </div>

           <h2 className="text-2xl font-black uppercase text-blue-900 mb-8 z-10">Daily Hydration</h2>

           <div className="relative w-48 h-72 border-l-4 border-r-4 border-b-4 border-white/60 bg-white/20 backdrop-blur-sm rounded-b-[3rem] shadow-2xl mb-10 overflow-hidden z-10 ring-1 ring-blue-100">
              <div className="absolute top-4 right-4 w-2 h-40 bg-white/30 rounded-full blur-sm z-20"></div>
              
              <div 
                 className={`absolute bottom-0 left-0 w-full bg-blue-500 transition-all duration-700 cubic-bezier(0.4, 0, 0.2, 1) flex items-start justify-center overflow-hidden ${isDropping ? 'translate-y-[120%] scale-x-75 duration-300 ease-in' : ''}`}
                 style={{ height: `${(waterCount / 8) * 100}%` }}
              >
                 <div className="absolute -top-3 left-0 w-[200%] h-6 bg-blue-400 opacity-50 rounded-[40%] animate-[spin_4s_linear_infinite] origin-center transform -translate-x-1/4"></div>
                 <div className="absolute -top-3 left-0 w-[200%] h-6 bg-blue-500 rounded-[45%] animate-[spin_6s_linear_infinite_reverse] origin-center transform -translate-x-1/4"></div>
                 
                 <div className="absolute inset-0 w-full h-full">
                    {waterCount > 0 && BUBBLES.map(bubble => (
                      <div 
                        key={bubble.id}
                        className="absolute bg-white/30 rounded-full animate-bubble-rise"
                        style={{
                          left: bubble.left,
                          width: `${bubble.size}px`,
                          height: `${bubble.size}px`,
                          bottom: '-20px',
                          animationDelay: `${bubble.delay}s`,
                          animationDuration: `${bubble.duration}s`
                        }}
                      ></div>
                    ))}
                 </div>
              </div>

              <div className="absolute inset-0 flex flex-col justify-evenly py-4 px-2 pointer-events-none opacity-30">
                 <div className="w-4 h-0.5 bg-blue-900 self-end"></div>
                 <div className="w-6 h-0.5 bg-blue-900 self-end"></div>
                 <div className="w-4 h-0.5 bg-blue-900 self-end"></div>
                 <div className="w-6 h-0.5 bg-blue-900 self-end"></div>
                 <div className="w-4 h-0.5 bg-blue-900 self-end"></div>
                 <div className="w-6 h-0.5 bg-blue-900 self-end"></div>
                 <div className="w-4 h-0.5 bg-blue-900 self-end"></div>
              </div>
           </div>

           <div className="text-4xl font-black text-blue-600 mb-8 tabular-nums tracking-tighter">
             {waterCount} <span className="text-lg text-blue-300 font-bold">/ 8</span>
           </div>

           <button 
             onClick={handleDrinkWater}
             disabled={isDropping}
             className="relative group w-full max-w-xs py-4 bg-blue-500 text-white font-black text-xl uppercase tracking-widest rounded-full shadow-[0_10px_30px_rgba(59,130,246,0.4)] hover:bg-blue-600 hover:shadow-[0_15px_40px_rgba(59,130,246,0.6)] active:scale-95 transition-all overflow-hidden"
           >
              <span className="relative z-10 flex items-center justify-center gap-2">
                 <Droplet className={`w-6 h-6 ${waterCount >= 8 ? 'animate-bounce' : ''}`} />
                 {waterCount >= 8 ? 'Finish Bottle' : 'Drink Water'}
              </span>
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 rounded-full"></div>
           </button>
           
           <style>{`
             @keyframes bubble-rise {
               0% { transform: translateY(0) scale(1); opacity: 0; }
               20% { opacity: 0.6; }
               100% { transform: translateY(-300px) scale(1.2); opacity: 0; }
             }
             .animate-bubble-rise {
               animation-name: bubble-rise;
               animation-timing-function: linear;
               animation-iteration-count: infinite;
             }
           `}</style>
        </div>
      )}
    </div>
  );
};

export default ExerciseProtocol;
