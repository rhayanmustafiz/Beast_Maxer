
import React, { useState } from 'react';
import { AnalysisResult } from '../types';
import { AlertTriangle, Crosshair, Zap, Droplet, ShoppingBag, Dumbbell, Activity, CheckCircle2, Skull, Share2, Check } from 'lucide-react';

interface Props {
  result: AnalysisResult;
  userImage?: string; // Front image for avatar
}

const BeastDashboard: React.FC<Props> = ({ result, userImage }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Safe defaults if AI misses a field in legacy data
  const overall = result.overallScore || 0;
  const potential = result.potentialScore || 0;
  const masculinity = result.masculinityScore || 50;
  const skin = result.skinQualityScore || 50;
  const jawline = result.jawlineScore || 50;
  const cheekbones = result.cheekboneScore || 50;

  // Helper for progress bar width
  const getWidth = (score: number) => `${score}%`;

  // Normalize recommendedProducts to handle array or object structure safely
  const recommendedProducts = Array.isArray(result.hairAnalysis?.recommendedProducts)
    ? result.hairAnalysis.recommendedProducts
    : (result.hairAnalysis?.recommendedProducts as any)?.items || [];

  const handleShare = (item: any, index: number) => {
    const url = window.location.origin;
    const text = `Beast Protocol: ${item.title} - ${item.description}\nGet analyzed at: ${url}`;
    
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        setCopiedIndex(index);
        setTimeout(() => setCopiedIndex(null), 2000);
      }).catch(err => console.error('Failed to copy:', err));
    }
  };

  return (
    <div className="max-w-md mx-auto p-4 space-y-8 animate-fade-in pb-20 relative">
      
      {/* --- MAIN RESULTS CARD (Umax Style) --- */}
      <div className="mt-12 mb-8 relative">
        {/* Card Background */}
        <div className="bg-beast-card border border-beast-border rounded-3xl p-6 pt-16 relative shadow-2xl transition-colors">
          
          {/* Avatar (Floating Top Center) */}
          <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 rounded-full border-4 border-beast-card overflow-hidden bg-beast-bg shadow-xl z-10 transition-colors">
            {userImage ? (
              <img src={userImage} alt="User" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-beast-bg text-beast-muted">
                <Skull />
              </div>
            )}
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-2 gap-y-6 gap-x-6 mt-4">
            
            {/* Overall */}
            <div>
              <p className="text-xs text-beast-muted font-medium mb-1">Overall</p>
              <div className="text-4xl font-black text-beast-text leading-none mb-2">{overall}</div>
              <div className="h-2 w-full bg-beast-border rounded-full overflow-hidden">
                <div className="h-full bg-yellow-400 rounded-full" style={{ width: getWidth(overall) }}></div>
              </div>
            </div>

            {/* Potential */}
            <div>
              <p className="text-xs text-beast-muted font-medium mb-1">Potential</p>
              <div className="text-4xl font-black text-beast-text leading-none mb-2">{potential}</div>
              <div className="h-2 w-full bg-beast-border rounded-full overflow-hidden">
                <div className="h-full bg-green-500 rounded-full" style={{ width: getWidth(potential) }}></div>
              </div>
            </div>

            {/* Masculinity */}
            <div>
              <p className="text-xs text-beast-muted font-medium mb-1">Masculinity</p>
              <div className="text-4xl font-black text-beast-text leading-none mb-2">{masculinity}</div>
              <div className="h-2 w-full bg-beast-border rounded-full overflow-hidden">
                <div className="h-full bg-[#9f1239] rounded-full" style={{ width: getWidth(masculinity) }}></div>
              </div>
            </div>

            {/* Skin Quality */}
            <div>
              <p className="text-xs text-beast-muted font-medium mb-1">Skin quality</p>
              <div className="text-4xl font-black text-beast-text leading-none mb-2">{skin}</div>
              <div className="h-2 w-full bg-beast-border rounded-full overflow-hidden">
                <div className="h-full bg-yellow-500 rounded-full" style={{ width: getWidth(skin) }}></div>
              </div>
            </div>

            {/* Jawline */}
            <div>
              <p className="text-xs text-beast-muted font-medium mb-1">Jawline</p>
              <div className="text-4xl font-black text-beast-text leading-none mb-2">{jawline}</div>
              <div className="h-2 w-full bg-beast-border rounded-full overflow-hidden">
                <div className="h-full bg-orange-600 rounded-full" style={{ width: getWidth(jawline) }}></div>
              </div>
            </div>

            {/* Cheekbones */}
            <div>
              <p className="text-xs text-beast-muted font-medium mb-1">Cheekbones</p>
              <div className="text-4xl font-black text-beast-text leading-none mb-2">{cheekbones}</div>
              <div className="h-2 w-full bg-beast-border rounded-full overflow-hidden">
                <div className="h-full bg-orange-600 rounded-full" style={{ width: getWidth(cheekbones) }}></div>
              </div>
            </div>

          </div>
          
          <div className="text-center mt-6 text-beast-muted/50 font-black text-sm tracking-widest uppercase">
            Beast Maxer
          </div>
        </div>
      </div>

      {/* --- BRUTAL TRUTH --- */}
      <div className="bg-beast-card border border-beast-border p-6 relative overflow-hidden rounded-xl transition-colors">
          <div className="absolute -right-6 -top-6 w-32 h-32 opacity-10 pointer-events-none grayscale">
            <img src="./logo.png" alt="Watermark" className="w-full h-full object-contain" />
          </div>
          <h3 className="text-beast-red font-black uppercase text-xl mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" /> The Brutal Truth
          </h3>
          {/* Scrollable container for text safety */}
          <div className="max-h-[200px] overflow-y-auto pr-2 custom-scrollbar">
            <p className="text-sm text-beast-text leading-relaxed font-mono italic whitespace-pre-wrap break-words">
              "{result.brutalTruth}"
            </p>
          </div>
      </div>

      {/* --- DETAILED ANALYSIS --- */}
      <div className="space-y-4">
        {/* Jawline */}
        <div className="bg-beast-bg border border-beast-border p-5 rounded-xl transition-colors">
          <h4 className="text-xs font-bold text-beast-muted uppercase mb-2 tracking-widest flex items-center gap-2">
            <Crosshair className="w-3 h-3" /> Jaw & Structure
          </h4>
          <p className="text-beast-text text-lg font-bold mb-1">{result.jawlineAnalysis?.quality || "Analyzing..."}</p>
          <p className="text-xs text-beast-red mb-2 break-words">{result.jawlineAnalysis?.flaws || "No significant flaws detected."}</p>
          <p className="text-xs text-beast-muted border-l border-beast-border pl-2 break-words">{result.jawlineAnalysis?.advice || "Maintain current routine."}</p>
        </div>

        {/* Body Analysis (Optional) */}
        <div className="bg-beast-bg border border-beast-border p-5 rounded-xl transition-colors">
          <h4 className="text-xs font-bold text-beast-muted uppercase mb-2 tracking-widest flex items-center gap-2">
            <Dumbbell className="w-3 h-3" /> Body Physics
          </h4>
          {result.bodyAnalysis ? (
            <>
              <div className="flex justify-between items-start mb-2">
                 <p className="text-beast-text font-bold">{result.bodyAnalysis.detectedShape}</p>
                 <span className="bg-beast-text/10 text-xs px-2 py-0.5 rounded text-beast-text">{result.bodyAnalysis.fatPercentageEstimate}</span>
              </div>
              <p className="text-xs text-beast-muted mb-3 break-words">{result.bodyAnalysis.advice}</p>
              <div className="flex flex-wrap gap-1">
                {result.bodyAnalysis.workoutFocus?.map(w => (
                  <span key={w} className="text-[10px] uppercase font-bold bg-beast-red/10 text-beast-red px-2 py-1 rounded">
                    {w}
                  </span>
                )) || []}
              </div>
            </>
          ) : (
             <p className="text-beast-muted text-sm italic mt-4">Body data not uploaded. Estimate based on neck circumference suggested average physique.</p>
          )}
        </div>

         {/* Hair */}
         <div className="bg-beast-bg border border-beast-border p-5 flex flex-col rounded-xl transition-colors">
          <h4 className="text-xs font-bold text-beast-muted uppercase mb-2 tracking-widest flex items-center gap-2">
            <Zap className="w-3 h-3" /> Hair
          </h4>
          <div>
              <span className="text-[10px] text-beast-muted uppercase">Type & Texture</span>
              <p className="text-beast-text font-bold text-sm">{result.hairAnalysis?.detectedType || "Unknown"} - {result.hairAnalysis?.texture || "Unknown"}</p>
          </div>
          <div className="mt-4">
              <span className="text-[10px] text-beast-green uppercase flex items-center gap-1 mb-1">
                <ShoppingBag className="w-3 h-3" /> Protocol Products
              </span>
              <div className="flex flex-wrap gap-1">
                {recommendedProducts.map((prod: string, i: number) => (
                  <span key={i} className="px-2 py-1 bg-beast-card border border-beast-border text-[10px] text-beast-muted rounded-sm">
                    {prod}
                  </span>
                ))}
              </div>
          </div>
        </div>

        {/* Skin Deep Dive */}
        <div className="bg-beast-bg border border-beast-border p-5 flex flex-col rounded-xl transition-colors">
           <h4 className="text-xs font-bold text-beast-muted uppercase mb-2 tracking-widest flex items-center gap-2">
            <Droplet className="w-3 h-3" /> Skin Integrity
           </h4>
           <div className="mb-2">
             <span className="text-beast-text font-bold">{result.skinAnalysis?.type || "Standard"}</span>
             <span className="text-beast-muted text-xs ml-2">({result.skinAnalysis?.texture || "Normal"})</span>
           </div>
           
           <div className="mt-2 bg-beast-card p-3 border border-beast-border rounded transition-colors">
             <p className="text-[10px] text-beast-muted uppercase mb-1">Fix Routine</p>
             <p className="text-xs text-beast-text whitespace-pre-wrap leading-relaxed break-words">
               {result.skinAnalysis?.fixRoutine || "Hydrate and moisturize daily."}
             </p>
           </div>
        </div>
      </div>

      {/* --- ASSETS VS LIABILITIES --- */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-beast-card border border-beast-border p-6 rounded-xl transition-colors">
          <h3 className="text-beast-red font-bold uppercase mb-4">Liabilities (Fix These)</h3>
          <ul className="space-y-3">
            {result.liabilities?.map((l, i) => (
              <li key={i} className="flex items-start gap-3 text-sm text-beast-muted">
                <span className="text-beast-red font-mono">[-]</span> {l}
              </li>
            )) || <li className="text-xs text-beast-muted">None detected.</li>}
          </ul>
        </div>
        <div className="bg-beast-card border border-beast-border p-6 rounded-xl transition-colors">
          <h3 className="text-beast-green font-bold uppercase mb-4">Assets (Maximize These)</h3>
          <ul className="space-y-3">
            {result.assets?.map((a, i) => (
              <li key={i} className="flex items-start gap-3 text-sm text-beast-muted">
                <span className="text-beast-green font-mono">[+]</span> {a}
              </li>
            )) || <li className="text-xs text-beast-muted">Standard aesthetics.</li>}
          </ul>
        </div>
      </div>

      {/* --- BEAST PROTOCOL --- */}
      <div>
        <h3 className="text-2xl font-black text-beast-text uppercase italic tracking-tighter mb-6">
          The <span className="text-beast-green">Protocol</span>
        </h3>
        <div className="space-y-3">
          {result.protocol?.map((item, idx) => (
            <div key={idx} className="bg-beast-bg border border-beast-border p-4 flex gap-4 items-center transition-all hover:border-beast-text/30 rounded-xl">
              <div className={`text-xs font-bold px-2 py-1 h-fit ${
                item.impact === 'HIGH' ? 'bg-beast-red text-black' : 'bg-beast-border text-beast-muted'
              }`}>
                {item.impact}
              </div>
              <div className="flex-1">
                <h4 className="text-beast-text font-bold text-sm flex items-center gap-2">
                  {item.title}
                  {item.impact === 'HIGH' && <Activity className="w-3 h-3 text-beast-red animate-pulse" />}
                </h4>
                <p className="text-beast-muted text-xs break-words">{item.description}</p>
              </div>
              <div className="flex gap-2">
                 <button 
                   onClick={() => handleShare(item, idx)}
                   className="p-2 text-beast-muted hover:text-beast-text transition-colors rounded-full hover:bg-beast-text/10"
                   title="Share Protocol"
                 >
                   {copiedIndex === idx ? <Check className="w-4 h-4 text-green-500" /> : <Share2 className="w-4 h-4" />}
                 </button>
                 <CheckCircle2 className="w-5 h-5 text-beast-border mt-1.5" />
              </div>
            </div>
          )) || <div className="text-beast-muted text-sm">No protocol data available.</div>}
        </div>
      </div>

    </div>
  );
};

export default BeastDashboard;
