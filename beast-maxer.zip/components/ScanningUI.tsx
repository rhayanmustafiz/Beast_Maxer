
import React, { useEffect, useState } from 'react';
import { Loader2, Scan, Grid, Activity, BrainCircuit } from 'lucide-react';

interface Props {
  frontImage: string;
  sideImage: string;
}

const PHASES = [
  { text: "Mapping Facial Geometry...", icon: Grid, color: "text-blue-400" },
  { text: "Analyzing Skin Texture...", icon: Scan, color: "text-purple-400" },
  { text: "Calculating Bone Structure...", icon: Activity, color: "text-green-400" },
  { text: "Finalizing Biometric Score...", icon: BrainCircuit, color: "text-beast-red" }
];

const METRICS = [
  { label: "Overall", color: "bg-yellow-400", glow: "shadow-yellow-400/50" },
  { label: "Potential", color: "bg-green-500", glow: "shadow-green-500/50" },
  { label: "Masculinity", color: "bg-red-500", glow: "shadow-red-500/50" },
  { label: "Skin Quality", color: "bg-purple-400", glow: "shadow-purple-400/50" },
  { label: "Jawline", color: "bg-orange-500", glow: "shadow-orange-500/50" },
  { label: "Cheekbones", color: "bg-blue-400", glow: "shadow-blue-400/50" },
];

const ScanningUI: React.FC<Props> = ({ frontImage, sideImage }) => {
  const [phaseIndex, setPhaseIndex] = useState(0);
  const [metricsValues, setMetricsValues] = useState<number[]>(METRICS.map(() => 0));

  // Phase Transition Logic
  useEffect(() => {
    const phaseInterval = setInterval(() => {
      setPhaseIndex(prev => (prev < PHASES.length - 1 ? prev + 1 : prev));
    }, 2500); // Change phase every 2.5 seconds

    return () => clearInterval(phaseInterval);
  }, []);

  // Metrics Data Simulation (Converging effect)
  useEffect(() => {
    const updateMetrics = () => {
      setMetricsValues(prev => prev.map((val, i) => {
        // As phases progress, variation decreases to simulate "locking on" to a value
        const target = 75; // Hypothetical convergence point
        const noise = Math.random() * (20 - (phaseIndex * 5)); // Noise reduces over time
        const drift = (target - val) * 0.1; // Move 10% towards target
        return Math.min(99, Math.max(1, Math.floor(val + drift + noise - 10))); 
      }));
    };

    // Fast updates for digital look
    const metricInterval = setInterval(updateMetrics, 80);
    return () => clearInterval(metricInterval);
  }, [phaseIndex]);

  const CurrentIcon = PHASES[phaseIndex].icon;

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] px-6 max-w-md mx-auto w-full animate-fade-in">
      
      {/* Top Section: Analysis Visual */}
      <div className="relative mb-12 flex justify-center items-center w-full max-w-[300px] aspect-square">
        {/* Rotating Rings */}
        <div className="absolute inset-0 border border-beast-border/30 rounded-full animate-[spin_10s_linear_infinite]"></div>
        <div className="absolute inset-4 border border-beast-red/20 rounded-full animate-[spin_7s_linear_infinite_reverse]"></div>
        <div className="absolute inset-0 bg-beast-red/5 rounded-full blur-3xl animate-pulse"></div>

        {/* Central Avatar Display */}
        <div className="relative flex items-center justify-center">
          <div className="w-32 h-32 rounded-full overflow-hidden relative z-10 border-2 border-beast-red/50 shadow-[0_0_30px_rgba(220,38,38,0.3)] bg-black">
             {/* Crossfade Images */}
             <img 
               src={frontImage} 
               alt="Scan" 
               className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${phaseIndex % 2 === 0 ? 'opacity-100' : 'opacity-0'}`} 
             />
             <img 
               src={sideImage} 
               alt="Scan" 
               className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${phaseIndex % 2 !== 0 ? 'opacity-100' : 'opacity-0'}`} 
             />
             
             {/* Scanning Grid Overlay */}
             <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,0,0.2)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,0,0.2)_1px,transparent_1px)] bg-[size:20px_20px] opacity-30"></div>
             
             {/* Laser Line */}
             <div className="absolute top-0 w-full h-1 bg-green-500 shadow-[0_0_10px_#22c55e] animate-scan-down opacity-80 z-20"></div>
          </div>
        </div>
      </div>

      {/* Phase Indicator */}
      <div className="flex items-center gap-3 mb-8 bg-beast-card px-6 py-3 rounded-full border border-beast-border shadow-lg">
        <CurrentIcon className={`w-5 h-5 ${PHASES[phaseIndex].color} animate-pulse`} />
        <span className="font-mono text-xs md:text-sm font-bold text-beast-text uppercase tracking-wider min-w-[200px] text-center">
          {PHASES[phaseIndex].text}
        </span>
      </div>

      {/* Metrics Grid */}
      <div className="w-full bg-beast-card border border-beast-border rounded-3xl p-6 shadow-2xl relative overflow-hidden transition-colors">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-beast-red to-transparent opacity-50"></div>
        
        <div className="grid grid-cols-2 gap-y-6 gap-x-6">
          {METRICS.map((metric, index) => (
            <div key={metric.label} className="flex flex-col gap-1">
              <div className="flex justify-between items-end">
                 <span className="text-[10px] text-beast-muted font-bold uppercase tracking-wider">{metric.label}</span>
                 <span className="text-xs font-mono text-beast-text/70">{metricsValues[index]}%</span>
              </div>
              <div className="h-1.5 w-full bg-beast-bg border border-beast-border/50 rounded-full overflow-hidden mt-1">
                <div 
                  className={`h-full ${metric.color} ${metric.glow} transition-all duration-75 ease-out`}
                  style={{ width: `${metricsValues[index]}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 flex justify-between items-center text-[10px] font-mono text-beast-muted border-t border-beast-border pt-4">
           {/* Text removed as requested */}
           <span className="flex items-center gap-1 text-green-500">
             <Activity className="w-3 h-3" /> PROCESSING
           </span>
        </div>
      </div>

      <style>{`
        @keyframes scan-down {
          0% { top: 0%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
        .animate-scan-down {
          animation: scan-down 1.5s cubic-bezier(0.4, 0, 0.2, 1) infinite;
        }
      `}</style>
    </div>
  );
};

export default ScanningUI;
