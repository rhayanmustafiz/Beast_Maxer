
import React, { useState, useMemo, useRef } from 'react';
import { QuestionnaireData } from '../types';
import { ArrowRight, Camera, Loader2, Check, AlertCircle, Upload, ArrowLeft } from 'lucide-react';
import { detectAttributeFromImage } from '../services/geminiService';

interface Props {
  initialAge: number;
  onComplete: (data: QuestionnaireData) => void;
  onBack: () => void;
}

const BeastQuestionnaire: React.FC<Props> = ({ initialAge, onComplete, onBack }) => {
  const [step, setStep] = useState(0);
  const [analyzing, setAnalyzing] = useState(false);
  
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Store answers.
  const [answers, setAnswers] = useState<Record<string, string[]>>({});

  const finalizeData = () => {
    const finalData: any = { age: initialAge };
    Object.keys(answers).forEach(key => {
      finalData[key] = answers[key].join(', ');
    });
    return finalData as QuestionnaireData;
  };

  const questions = useMemo(() => {
    const isYoung = initialAge < 18;
    const isAdult = initialAge >= 22;

    return [
      {
        key: 'hairCondition',
        title: 'Hair Status',
        multi: true, // Can have multiple issues
        canScan: true,
        options: ['Thick & Healthy', 'Oily / Greasy', 'Dry / Frizzy', 'Receding / Mature Hairline', 'Thinning / Balding', 'Dandruff Issues']
      },
      {
        key: 'physique',
        title: 'Current Physique',
        multi: false, // One body type
        canScan: true,
        options: ['Skinny / Frail', 'Skinny Fat (No muscle)', 'Athletic / Toned', 'Muscular / Bulk', 'Overweight', 'Obese']
      },
      {
        key: 'skinType',
        title: 'Skin Type',
        multi: false, // Usually one primary type
        canScan: true,
        options: ['Normal', 'Oily (Shiny)', 'Dry (Flaky)', 'Combination (T-Zone)', 'Sensitive (Redness)']
      },
      {
        key: 'posture',
        title: 'Posture Check',
        multi: false,
        canScan: false,
        options: ['Perfect / Upright', 'Slight Slouch', 'Nerd Neck (Head forward)', 'Rounded Shoulders', 'Severe Gamer Hunch']
      },
      {
        key: 'sleepQuality',
        title: 'Sleep Hygiene',
        multi: false,
        canScan: false,
        options: ['8+ Hours (Deep)', '6-7 Hours (Okay)', 'Fragmented / Insomnia', 'Less than 5 Hours', 'Inconsistent Schedule']
      },
      {
        key: 'diet',
        title: 'Nutrition Quality',
        multi: false,
        canScan: false,
        options: ['High Protein / Clean', 'Balanced Home Cooked', 'Junk Food / Sugars', 'Starvation / Low Calorie', 'Binge Eating']
      },
      {
        key: 'waterIntake',
        title: 'Hydration Level',
        multi: false,
        canScan: false,
        options: ['3+ Liters / Day', '1-2 Liters', 'Coffee/Soda mainly', 'Barely drink water']
      },
      {
        key: 'socialStatus',
        title: isYoung ? 'School Hierarchy' : (isAdult ? 'Social Dominance' : 'Social Status'),
        multi: false,
        canScan: false,
        options: isYoung 
          ? ['The Popular Guy', 'Known / Respected', 'Invisible / Background', 'The "Weird" Kid', 'Bullied Target']
          : ['Room Commander (Alpha)', 'High Status / Respected', 'Average / Blends In', 'Socially Awkward', 'Disrespected / Ignored']
      },
      {
        key: 'datingHistory',
        title: isYoung ? 'Female Interaction' : 'Dating Market Value',
        multi: false,
        canScan: false,
        options: isYoung
          ? ['Girls approach me', 'I talk to girls easily', 'I get nervous/shaky', 'Invisible to girls', 'Rejected often']
          : ['I get approached often', 'I approach successfully', 'I approach but get rejected', 'I am too scared to approach', 'Non-existent']
      }
    ];
  }, [initialAge]);

  const handleSelect = (value: string) => {
    const currentQ = questions[step];
    const currentAnswers = answers[currentQ.key] || [];
    let newAnswers: string[];

    if (currentQ.multi) {
      // Manual multi-select logic
      if (currentAnswers.includes(value)) {
        newAnswers = currentAnswers.filter(a => a !== value);
      } else {
        newAnswers = [...currentAnswers, value];
      }
    } else {
      // Single select
      newAnswers = [value];
    }

    setAnswers({ ...answers, [currentQ.key]: newAnswers });

    // Auto-advance if single select and manual click
    if (!currentQ.multi) {
      setTimeout(() => nextStep({ ...answers, [currentQ.key]: newAnswers }), 300);
    }
  };

  const nextStep = (currentAnswers = answers) => {
    const currentQ = questions[step];
    if (!currentAnswers[currentQ.key] || currentAnswers[currentQ.key].length === 0) return;

    if (step < questions.length - 1) {
      setStep(step + 1);
    } else {
      onComplete(finalizeData());
    }
  };

  // PrevStep function - Now handles going back to app home
  const prevStep = () => {
    if (step > 0) {
      setStep(step - 1);
    } else {
      onBack();
    }
  };

  const triggerCamera = () => {
    if (cameraInputRef.current) {
      cameraInputRef.current.value = '';
      cameraInputRef.current.click();
    }
  };

  const triggerUpload = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handlePhotoScan = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setAnalyzing(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      try {
        const base64 = reader.result as string;
        const currentQ = questions[step];
        const detected = await detectAttributeFromImage(base64, currentQ.title, currentQ.options);
        
        if (detected && detected.length > 0) {
          let finalSelection = detected;
          if (!currentQ.multi && detected.length > 1) {
             finalSelection = [detected[0]]; // Pick best match
          }

          const newAnswers = { ...answers, [currentQ.key]: finalSelection };
          setAnswers(newAnswers);
          
          setTimeout(() => {
             if (step < questions.length - 1) {
               setStep(step + 1);
             } else {
               onComplete(finalizeData());
             }
          }, 1500);
        } else {
           alert("AI couldn't detect a clear match. Please select manually.");
        }
      } catch (err: any) {
        console.error(err);
        alert("Scan Error: " + (err.message || "Try again."));
      } finally {
        setAnalyzing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const currentQ = questions[step];
  const selectedOptions = answers[currentQ.key] || [];

  return (
    <div className="max-w-xl mx-auto mt-10 p-4">
      
      {/* HEADER SECTION WITH NAVIGATION */}
      <div className="flex items-center justify-between mb-6 border-b border-beast-border pb-4">
        <div className="flex items-center gap-4">
          {/* Back Button (Always Visible now - Logic handled in prevStep) */}
           <button
             type="button"
             onClick={prevStep}
             className="p-2 bg-beast-bg border border-beast-border rounded-full hover:border-beast-red text-beast-muted hover:text-beast-red transition-all group"
             aria-label="Previous Question"
           >
              <ArrowLeft className="w-5 h-5 group-hover:-translate-x-0.5 transition-transform" />
           </button>

          <h2 className="text-2xl font-black uppercase italic tracking-tighter">
            <span className="text-beast-gold">Phase 1:</span> <span className="text-beast-red">Recon</span>
          </h2>
        </div>
        
        <span className="font-mono text-beast-red text-sm font-bold">
          {step + 1} / {questions.length}
        </span>
      </div>

      <div className="bg-beast-card border border-beast-border p-8 min-h-[400px] flex flex-col justify-center animate-fade-in relative shadow-xl rounded-xl">
        
        <div className="flex justify-between items-start mb-6">
          <h3 className="text-xl font-bold text-beast-text font-mono uppercase">
            {currentQ.title}
          </h3>
          {currentQ.canScan && (
             <div className="flex gap-2">
               {/* Camera Button */}
               <button 
                 type="button"
                 onClick={triggerCamera}
                 disabled={analyzing}
                 className="flex items-center gap-2 px-3 py-2 bg-beast-red/10 text-beast-red border border-beast-red/50 hover:bg-beast-red hover:text-white transition-all rounded text-xs font-bold uppercase"
               >
                 {analyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Camera className="w-4 h-4" />}
                 {analyzing ? "Scanning" : "Cam"}
               </button>

               {/* Upload Button */}
               <button 
                 type="button"
                 onClick={triggerUpload}
                 disabled={analyzing}
                 className="flex items-center gap-2 px-3 py-2 bg-beast-text/5 text-beast-muted border border-beast-border hover:bg-beast-text/10 hover:text-beast-text transition-all rounded text-xs font-bold uppercase"
               >
                 <Upload className="w-4 h-4" />
                 File
               </button>

               {/* Hidden Inputs */}
               <input 
                 type="file" 
                 ref={cameraInputRef} 
                 style={{ display: 'none' }}
                 accept="image/*"
                 capture="environment" 
                 onChange={handlePhotoScan} 
               />
               <input 
                 type="file" 
                 ref={fileInputRef} 
                 style={{ display: 'none' }}
                 accept="image/*"
                 onChange={handlePhotoScan} 
               />
             </div>
          )}
        </div>
        
        {currentQ.multi && (
          <p className="text-beast-muted text-xs mb-4 -mt-4">* Select multiple if needed</p>
        )}

        <div className="grid grid-cols-1 gap-3">
          {currentQ.options.map((opt) => {
            const isSelected = selectedOptions.includes(opt);
            return (
              <button
                key={opt}
                type="button" // EXPLICIT BUTTON TYPE
                onClick={() => handleSelect(opt)}
                className={`group flex items-center justify-between p-4 border transition-all text-left rounded-lg ${
                  isSelected 
                    ? 'bg-beast-green/10 border-beast-green text-beast-text' 
                    : 'bg-beast-bg border-beast-border hover:border-beast-red text-beast-muted hover:text-beast-text'
                }`}
              >
                <span className="font-medium transition-colors">
                  {opt}
                </span>
                {isSelected ? (
                  <Check className="w-4 h-4 text-beast-green" />
                ) : (
                  <ArrowRight className="w-4 h-4 text-beast-border group-hover:text-beast-red transition-colors opacity-0 group-hover:opacity-100" />
                )}
              </button>
            );
          })}
        </div>
        
        {/* Navigation Area */}
        <div className="mt-8 flex gap-3">
          {(currentQ.multi || selectedOptions.length > 0) && (
            <button 
              type="button" 
              onClick={() => nextStep()}
              disabled={selectedOptions.length === 0}
              className="w-full py-4 bg-beast-text text-beast-bg font-bold uppercase tracking-widest hover:opacity-90 disabled:opacity-50 transition-all shadow-lg rounded-lg"
            >
              {step === questions.length - 1 ? "Finish Phase 1" : "Next Data Point"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default BeastQuestionnaire;
