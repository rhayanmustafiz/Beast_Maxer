
import React, { useEffect, useRef } from 'react';

const AdDisplay: React.FC = () => {
  const scriptContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!scriptContainerRef.current) return;

    // Prevent duplicate injection
    const existingScript = scriptContainerRef.current.querySelector('script[src*="effectivegatecpm"]');
    if (existingScript) return;

    const script = document.createElement('script');
    script.async = true;
    script.setAttribute('data-cfasync', 'false');
    script.src = "https://pl28398508.effectivegatecpm.com/67aafc607363cc244888abd14e7164bc/invoke.js";
    
    scriptContainerRef.current.appendChild(script);

    return () => {
      // Cleanup handled by React unmounting
    };
  }, []);

  return (
    <div className="w-full flex flex-col items-center py-6 bg-beast-bg z-40 relative gap-6 overflow-hidden min-h-[100px]">
      {/* Native Banner Script Container */}
      <div className="w-full flex justify-center items-center relative">
         {/* Script Container */}
         <div ref={scriptContainerRef}></div>
         {/* Target Div for the Script */}
         <div id="container-67aafc607363cc244888abd14e7164bc"></div>
      </div>
    </div>
  );
};

export default AdDisplay;
