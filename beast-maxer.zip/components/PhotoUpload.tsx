
import React, { useRef, useState } from 'react';
import { Camera, X, CheckCircle, ScanFace, AlertTriangle, Loader2, Dumbbell, Upload } from 'lucide-react';
import { validateImageContent } from '../services/geminiService';

interface Props {
  onImagesReady: (front: string, side: string, body: string | null) => void;
}

const PhotoUpload: React.FC<Props> = ({ onImagesReady }) => {
  const [frontImage, setFrontImage] = useState<string | null>(null);
  const [sideImage, setSideImage] = useState<string | null>(null);
  const [bodyImage, setBodyImage] = useState<string | null>(null);
  
  const [validating, setValidating] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // References for Camera (capture enforced)
  const frontCamRef = useRef<HTMLInputElement>(null);
  const sideCamRef = useRef<HTMLInputElement>(null);
  const bodyCamRef = useRef<HTMLInputElement>(null);

  // References for Upload (gallery)
  const frontFileRef = useRef<HTMLInputElement>(null);
  const sideFileRef = useRef<HTMLInputElement>(null);
  const bodyFileRef = useRef<HTMLInputElement>(null);

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>, type: 'FRONT' | 'SIDE' | 'BODY') => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMsg(null);
    setValidating(type);

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      try {
        const validation = await validateImageContent(base64, type);
        if (validation.valid) {
          // Use compressed version if available to save memory
          const finalImage = validation.compressedBase64 || base64;
          if (type === 'FRONT') setFrontImage(finalImage);
          if (type === 'SIDE') setSideImage(finalImage);
          if (type === 'BODY') setBodyImage(finalImage);
        } else {
          setErrorMsg(validation.message || `Invalid ${type.toLowerCase()} photo.`);
        }
      } catch (err: any) {
        console.error(err);
        const msg = err?.message || "";
        setErrorMsg("Validation check failed. Try again.");
      } finally {
        setValidating(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const resetImage = (type: 'FRONT' | 'SIDE' | 'BODY') => {
    if (type === 'FRONT') setFrontImage(null);
    if (type === 'SIDE') setSideImage(null);
    if (type === 'BODY') setBodyImage(null);
    setErrorMsg(null);
  };

  const triggerInput = (ref: React.RefObject<HTMLInputElement>) => {
    if (ref.current) {
      ref.current.value = ''; // Reset value to allow selecting the same file again
      ref.current.click();
    }
  };

  // Skeleton Loader Component with Scanning Effect
  const SkeletonLoader = () => (
    <div className="absolute inset-0 bg-beast-card z-20 flex flex-col items-center justify-center overflow-hidden">
      {/* Background Grid Animation */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:20px_20px]" />
      
      {/* Wireframe Face/Body Placeholder */}
      <div className="w-32 h-32 rounded-full border-2 border-beast-border/30 mb-4 relative overflow-hidden animate-pulse">
         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 bg-beast-border/10 rounded-full" />
         <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-16 h-8 bg-beast-border/10 rounded-t-xl" />
      </div>
      
      {/* Scanning Line */}
      <div className="absolute top-0 left-0 w-full h-[2px] bg-beast-red shadow-[0_0_15px_var(--beast-primary)] animate-[scan-down_1.5s_ease-in-out_infinite] z-30" />
      
      {/* Shimmer Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/5 to-transparent animate-[shimmer_2s_infinite]" />

      <div className="flex items-center gap-2 mt-4 text-beast-red font-mono text-xs font-bold animate-pulse z-40">
        <Loader2 className="w-4 h-4 animate-spin" />
        VALIDATING...
      </div>

      <style>{`
        @keyframes scan-down {
          0% { top: 0%; opacity: 0; }
          15% { opacity: 1; }
          85% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
      `}</style>
    </div>
  );

  const renderUploadBox = (
    title: string, 
    type: 'FRONT' | 'SIDE' | 'BODY', 
    image: string | null, 
    Icon: any, 
    camRef: React.RefObject<HTMLInputElement>,
    fileRef: React.RefObject<HTMLInputElement>,
    camCaptureMode: 'user' | 'environment'
  ) => (
    <div 
      className={`relative border-2 border-dashed h-80 flex flex-col items-center justify-center transition-all overflow-hidden bg-beast-card rounded-xl group ${
        image ? 'border-beast-green' : 'border-beast-border hover:border-beast-text/30'
      }`}
    >
      {validating === type && <SkeletonLoader />}

      {image && !validating ? (
        <>
          <img src={image} alt={title} className="absolute inset-0 w-full h-full object-cover opacity-80" />
          <div className="absolute inset-0 bg-black/40" />
          <button 
            onClick={() => resetImage(type)}
            className="absolute top-2 right-2 p-2 bg-black/50 text-white rounded-full hover:bg-red-600 transition-colors z-10"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="relative z-10 flex flex-col items-center">
            <CheckCircle className="w-10 h-10 text-beast-green mb-2 drop-shadow-md" />
            <span className="text-white font-bold uppercase tracking-wider text-sm">{title} Ready</span>
          </div>
        </>
      ) : (
        <div className={`flex flex-col items-center gap-4 p-6 text-center transition-opacity ${validating === type ? 'opacity-0' : 'opacity-100'}`}>
          <div className="p-4 bg-beast-bg rounded-full group-hover:scale-110 transition-transform duration-300 border border-beast-border">
            <Icon className="w-8 h-8 text-beast-muted group-hover:text-beast-red transition-colors" />
          </div>
          <div>
            <h3 className="font-bold text-beast-text uppercase text-sm mb-1">{title}</h3>
            <p className="text-[10px] text-beast-muted max-w-[150px] mx-auto leading-relaxed">
              {type === 'FRONT' && 'Direct eye contact. Neutral expression. Good lighting.'}
              {type === 'SIDE' && '90-degree profile. Jawline visible. Look straight ahead.'}
              {type === 'BODY' && 'Optional. Shirtless/fitted clothes for physique analysis.'}
            </p>
          </div>
          
          <div className="flex gap-2 w-full mt-2">
            <button 
              onClick={() => triggerInput(camRef)}
              className="flex-1 py-2 bg-beast-text text-beast-bg text-xs font-bold uppercase rounded hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
            >
              <Camera className="w-3 h-3" /> Camera
            </button>
            <button 
              onClick={() => triggerInput(fileRef)}
              className="flex-1 py-2 bg-transparent border border-beast-border text-beast-muted text-xs font-bold uppercase rounded hover:text-beast-text hover:border-beast-text transition-all flex items-center justify-center gap-2"
            >
              <Upload className="w-3 h-3" /> Upload
            </button>
          </div>

          <input 
            type="file" 
            ref={camRef} 
            className="hidden" 
            accept="image/*" 
            capture={camCaptureMode}
            onChange={(e) => handleFile(e, type)} 
          />
          <input 
            type="file" 
            ref={fileRef} 
            className="hidden" 
            accept="image/*" 
            onChange={(e) => handleFile(e, type)} 
          />
        </div>
      )}
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8 animate-fade-in pb-24">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-black text-beast-text uppercase italic tracking-tighter mb-2">
          <span className="text-beast-gold">Phase 2:</span> <span className="text-beast-red">Visual Data</span>
        </h2>
        <p className="text-beast-muted font-mono text-xs">AI-Enhanced Biometric Scanning Protocol</p>
      </div>

      {errorMsg && (
        <div className="max-w-md mx-auto mb-6 p-4 bg-red-900/20 border border-red-500/50 rounded flex items-center gap-3 animate-pulse">
          <AlertTriangle className="w-5 h-5 text-red-500" />
          <span className="text-red-400 text-xs font-mono">{errorMsg}</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {renderUploadBox("Front Profile", "FRONT", frontImage, ScanFace, frontCamRef, frontFileRef, "user")}
        {renderUploadBox("Side Profile", "SIDE", sideImage, ScanFace, sideCamRef, sideFileRef, "environment")}
        {renderUploadBox("Physique (Opt)", "BODY", bodyImage, Dumbbell, bodyCamRef, bodyFileRef, "environment")}
      </div>

      <div className="fixed bottom-0 left-0 w-full bg-beast-bg/90 backdrop-blur-md p-4 border-t border-beast-border z-10 flex justify-center">
         <button
           onClick={() => {
             if (frontImage && sideImage) {
               onImagesReady(frontImage, sideImage, bodyImage);
             }
           }}
           disabled={!frontImage || !sideImage}
           className="w-full max-w-md py-4 bg-beast-red text-black font-black text-lg uppercase tracking-widest hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-[0_0_20px_rgba(220,38,38,0.4)] rounded-lg"
         >
           Begin Analysis
         </button>
      </div>
    </div>
  );
};

export default PhotoUpload;
