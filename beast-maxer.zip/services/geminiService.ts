
import { GoogleGenAI, Type, Schema, Chat, HarmCategory, HarmBlockThreshold } from "@google/genai";
import { AnalysisResult, QuestionnaireData } from "../types";

// CONSTANTS
// STRICTLY GEMINI-2.5-FLASH FOR SPEED AND STABILITY
const PRIMARY_MODEL = "gemini-2.5-flash";
const CHAT_MODEL = "gemini-2.5-flash"; 

// --- FAILSAFE API KEY ---
// Added to prevent crashes on web deployments where .env variables might be missing.
const FALLBACK_KEY = "AIzaSyBANUYDV292_iiBtEeayX2rsP8tW66rr4A";

const getApiKey = () => {
  let key = "";
  
  // 1. Check standard process.env (Node/Webpack/Bundler replaced)
  try {
    if (typeof process !== 'undefined' && process.env) {
      // Prioritize common web keys if process.env exists
      if (process.env.VITE_API_KEY) key = process.env.VITE_API_KEY;
      else if (process.env.NEXT_PUBLIC_API_KEY) key = process.env.NEXT_PUBLIC_API_KEY;
      else if (process.env.REACT_APP_API_KEY) key = process.env.REACT_APP_API_KEY;
      else if (process.env.API_KEY) key = process.env.API_KEY;
    }
  } catch (e) { console.warn("process.env access failed", e); }

  // 2. Check import.meta.env (Vite Standard)
  if (!key) {
    try {
      // @ts-ignore
      if (typeof import.meta !== 'undefined' && import.meta.env) {
        // @ts-ignore
        if (import.meta.env.VITE_API_KEY) key = import.meta.env.VITE_API_KEY;
        // @ts-ignore
        else if (import.meta.env.API_KEY) key = import.meta.env.API_KEY;
      }
    } catch (e) { console.warn("import.meta.env access failed", e); }
  }
  
  // 3. CRITICAL FIX: Use Fallback Key if environment variables fail
  if (!key) {
    console.log("Environment key missing. Using Failsafe Key.");
    key = FALLBACK_KEY;
  }
  
  if (key) return key;

  console.error("CRITICAL: API Key is missing.");
  throw new Error("API Key is missing. Please check your deployment configuration (VITE_API_KEY or API_KEY).");
};

// Helper: Client-side Image Compression
const compressImage = (base64Str: string, maxWidth = 640): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64Str;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;
      
      if (width > maxWidth) {
        height = Math.round((height * maxWidth) / width);
        width = maxWidth;
      }
      
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(base64Str);
        return;
      }
      // Medium quality smoothing is faster
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'medium';
      ctx.drawImage(img, 0, 0, width, height);
      // 0.6 quality is the sweet spot for AI analysis vs file size (prevent payload errors)
      resolve(canvas.toDataURL('image/jpeg', 0.6)); 
    };
    img.onerror = () => resolve(base64Str); 
  });
};

// CRITICAL FIX: Robust JSON Cleaning
const cleanJSON = (text: string): string => {
  if (!text) return "{}";
  let cleaned = text.trim();
  
  // 1. Remove Markdown code blocks case-insensitively
  cleaned = cleaned.replace(/^```(json)?/im, "");
  cleaned = cleaned.replace(/```$/im, "");
  
  // 2. Find the first '{' and last '}' to strip outside noise
  const firstOpen = cleaned.indexOf('{');
  const lastClose = cleaned.lastIndexOf('}');
  
  if (firstOpen !== -1 && lastClose !== -1 && lastClose > firstOpen) {
    cleaned = cleaned.substring(firstOpen, lastClose + 1);
  }

  return cleaned.trim();
};

const cleanRepetitiveText = (text: string): string => {
  if (!text) return text;
  const repetitionRegex = /(\b\w+\b)(?:\s+\1){2,}/gi;
  let cleaned = text.replace(repetitionRegex, "$1");
  if (cleaned.includes("inging inging")) {
    cleaned = cleaned.replace(/inging\s+inging(?:\s+inging)*/g, "...");
  }
  return cleaned;
};

// SYSTEM PROMPT
const SYSTEM_PROMPT = `
ACT AS: Elite Aesthetics Coach & Craniofacial Analyst (Beast Mode).
TASK: Analyze photos and provide a "Beast Protocol" for self-improvement.
MODEL: GEMINI-2.5-FLASH.

STRICT VISUAL ANALYSIS RULES:
1. LOOK AT THE PHOTOS. Identify weak jawlines, skin issues, asymmetries, fat storage, recessed chins, thinning hair.
2. BRUTAL HONESTY. Do not sugarcoat. If they have a weak chin, say it. If they are skinny fat, say it.
3. REJECT FAKES. If the image is not a real person, set "overallScore" to 0.

ADVICE & ROUTINE GUIDELINES (HOMEMADE & NATURAL ONLY):
- The 'protocol' MUST be HOMEMADE and NATURAL.
- FORBIDDEN: Do not suggest surgery, fillers, botox, or expensive clinical treatments.
- ALLOWED:
  * Structure: Mewing (tongue posture), Hard Gum Chewing (Mastic), Chin Tucks, Bonesmashing (mild), Thumb Pulling.
  * Skin: Ice water face dips, Pillowcase hygiene, Diet changes (No sugar/dairy), Gua Sha, Microneedling (at home).
  * Fitness: Neck curls, Caloric deficit, Sprinting.
- Be actionable. Example: "Chew Mastic Gum 30 mins/day" instead of "Improve jawline".

SCORING: 
- 50 is Average. 80 is Attractive. 95+ is Model. Be realistic.

OUTPUT JSON ONLY.
`;

const RESPONSE_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    overallScore: { type: Type.NUMBER, description: "Strict ABI score 0-100." },
    potentialScore: { type: Type.NUMBER, description: "Genetic max score 0-100." },
    masculinityScore: { type: Type.NUMBER, description: "Sexual dimorphism score." },
    skinQualityScore: { type: Type.NUMBER, description: "Real dermatological score." },
    jawlineScore: { type: Type.NUMBER, description: "Mandibular definition score." },
    cheekboneScore: { type: Type.NUMBER, description: "Zygomatic prominence score." },
    
    potentialGraph: {
      type: Type.OBJECT,
      properties: {
        current: { type: Type.NUMBER },
        max: { type: Type.NUMBER },
        color: { type: Type.STRING, enum: ["RED", "YELLOW", "GREEN"] }
      }
    },
    jawlineAnalysis: {
      type: Type.OBJECT,
      properties: {
        quality: { type: Type.STRING, description: "e.g., 'Weak', 'Recessed', 'Sharp', 'Defined'" },
        flaws: { type: Type.STRING, description: "Specific visual flaws." },
        advice: { type: Type.STRING, description: "Natural/Homemade fix (e.g. Mewing, Chewing)." },
      }
    },
    hairAnalysis: {
      type: Type.OBJECT,
      properties: {
        detectedType: { type: Type.STRING },
        texture: { type: Type.STRING },
        advice: { type: Type.STRING },
        recommendedProducts: { type: Type.ARRAY, items: { type: Type.STRING } }
      }
    },
    skinAnalysis: {
      type: Type.OBJECT,
      properties: {
        texture: { type: Type.STRING },
        type: { type: Type.STRING },
        issues: { type: Type.ARRAY, items: { type: Type.STRING } },
        fixRoutine: { type: Type.STRING, description: "Step-by-step natural routine (e.g. Ice, Water, Diet)." }
      }
    },
    bodyAnalysis: {
      type: Type.OBJECT,
      properties: {
        detectedShape: { type: Type.STRING },
        fatPercentageEstimate: { type: Type.STRING },
        advice: { type: Type.STRING },
        workoutFocus: { type: Type.ARRAY, items: { type: Type.STRING } }
      },
      nullable: true
    },
    brutalTruth: { type: Type.STRING, description: "1-2 sentences. The absolute honest truth about their appearance. Identify the main Failo." },
    assets: { type: Type.ARRAY, items: { type: Type.STRING } },
    liabilities: { type: Type.ARRAY, items: { type: Type.STRING } },
    protocol: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: "Actionable step name (e.g. 'Start Mewing')." },
          description: { type: Type.STRING, description: "How to do it at home." },
          impact: { type: Type.STRING, enum: ["HIGH", "MED", "LOW"] }
        }
      }
    }
  },
  required: [
    "overallScore", "potentialScore", "masculinityScore", "skinQualityScore", "jawlineScore", "cheekboneScore",
    "potentialGraph", "jawlineAnalysis", "hairAnalysis", "skinAnalysis", "brutalTruth", "assets", "liabilities", "protocol"
  ]
};

const GLOBAL_CONTEXT = `
  GLOBAL KNOWLEDGE BASE:
  - **App Name**: Beast Maxer.
  - **Creators**: Owned by Rhayan & Ahasan.
  - **Philosophy**: Natural maximization first. Surgery last.

  GAME/QUIZ PROTOCOL (STRICT RULES):
  If the user asks for a game, quiz, or test:
  1. STEP 1: Ask "How many questions?" and STOP. Wait for the number.
  2. STEP 2: Loop through the questions ONE BY ONE. 
     - Ask Question 1 (A,B,C,D). Wait for Answer.
     - **CRITICAL**: Do NOT reveal if the answer is correct or wrong yet. Do NOT explain yet.
     - Say "Locked in." or "Noted." and immediately ask Question 2.
  3. STEP 3: After the LAST question is answered:
     - CALCULATE SCORE (e.g. 3/5).
     - ASSIGN RANK:
       * 0-20%: Bronze
       * 21-40%: Silver
       * 41-60%: Gold
       * 61-80%: Diamond
       * 81-100%: Grandmaster
     - **REVEAL & CORRECT**: Now list each question, what the user answered, what the correct answer was, and the explanation.
`;

// ---------------------------------------------------------
// Helpers
// ---------------------------------------------------------

export const validateImageContent = async (base64Image: string, expectedType: 'FRONT' | 'SIDE' | 'BODY'): Promise<{ valid: boolean; message?: string; compressedBase64?: string }> => {
  try {
    const apiKey = getApiKey();
    const ai = new GoogleGenAI({ apiKey });
    
    // 1. Compress first to save bandwidth
    const compressedBase64 = await compressImage(base64Image, 640);
    const cleanBase64 = compressedBase64.split(',')[1] || compressedBase64;

    // 2. Strict Prompts for gemini-2.5-flash
    let prompt = "";
    if (expectedType === 'FRONT') {
      prompt = "Is this a clear PHOTO of a REAL HUMAN FACE (Front View)? Reject memes, cartoons, drawings, animals, objects, or extremely blurry photos. Return JSON: { isRealHuman: boolean, reason: string }";
    } else if (expectedType === 'SIDE') {
      prompt = "Is this a clear PHOTO of a REAL HUMAN SIDE PROFILE / JAWLINE? Reject memes, cartoons, drawings, objects. Return JSON: { isRealHuman: boolean, reason: string }";
    } else {
      prompt = "Is this a photo of a human body or physique? Reject random objects. Return JSON: { isRealHuman: boolean, reason: string }";
    }

    const response = await ai.models.generateContent({
      model: PRIMARY_MODEL,
      contents: [
        {
          role: 'user',
          parts: [
            { inlineData: { mimeType: "image/jpeg", data: cleanBase64 } },
            { text: prompt },
          ]
        }
      ],
      config: { 
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isRealHuman: { type: Type.BOOLEAN },
            reason: { type: Type.STRING }
          }
        },
        temperature: 0.0 
      },
    });

    const cleanedText = cleanJSON(response.text || "{}");
    const result = JSON.parse(cleanedText);

    if (result.isRealHuman === false) {
      return { 
        valid: false, 
        message: result.reason || `Image rejected: Not a valid ${expectedType.toLowerCase()} photo.` 
      };
    }

    return { valid: true, compressedBase64 }; 

  } catch (e: any) {
    // FAIL OPEN: If API key is wrong, network is down, or quota exceeded, do NOT block the user during validation.
    console.warn("Validation check skipped due to error (Fail-Open):", e);
    return { valid: true, compressedBase64: base64Image }; 
  }
};

export const detectAttributeFromImage = async (base64Image: string, category: string, options: string[]): Promise<string[]> => {
  try {
    const apiKey = getApiKey();
    const ai = new GoogleGenAI({ apiKey });
    
    const compressedBase64 = await compressImage(base64Image, 400); 
    const cleanBase64 = compressedBase64.split(',')[1] || compressedBase64;

    const prompt = `
      Match image to: ${category}.
      Options: ${JSON.stringify(options)}.
      Return JSON: { selectedOptions: [string] }
    `;

    const response = await ai.models.generateContent({
      model: PRIMARY_MODEL,
      contents: [
        {
          role: 'user',
          parts: [
            { inlineData: { mimeType: "image/jpeg", data: cleanBase64 } },
            { text: prompt },
          ]
        }
      ],
      config: { 
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: { selectedOptions: { type: Type.ARRAY, items: { type: Type.STRING } } }
        },
        temperature: 0.1 
      },
    });
    
    const cleanedText = cleanJSON(response.text || "{}");
    const result = JSON.parse(cleanedText);
    return result.selectedOptions || [];
  } catch (e) { 
    console.error("Detection Error:", e);
    return []; 
  }
};

// ---------------------------------------------------------
// Main Analysis
// ---------------------------------------------------------
export const analyzeBeastMode = async (
  frontImage: string, 
  sideImage: string, 
  bodyImage: string | null, 
  data: QuestionnaireData
): Promise<AnalysisResult> => {
  const apiKey = getApiKey();
  const ai = new GoogleGenAI({ apiKey });

  const compressedFront = await compressImage(frontImage, 640);
  const compressedSide = await compressImage(sideImage, 640);
  const compressedBody = bodyImage ? await compressImage(bodyImage, 640) : null;

  // Build Parts
  const parts: any[] = [
    { text: `User Profile Data: ${JSON.stringify(data)}` },
    { text: "IMAGE 1: FRONT FACE. IMAGE 2: SIDE PROFILE." },
    { inlineData: { mimeType: "image/jpeg", data: compressedFront.split(',')[1] } },
    { inlineData: { mimeType: "image/jpeg", data: compressedSide.split(',')[1] } },
  ];

  if (compressedBody) {
    parts.push({ text: "IMAGE 3: BODY/PHYSIQUE" });
    parts.push({ inlineData: { mimeType: "image/jpeg", data: compressedBody.split(',')[1] } });
  }

  const safetySettings = [
    { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_NONE },
    { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_NONE },
    { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_NONE },
    { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_NONE },
  ];

  const MAX_RETRIES = 2;
  let lastError: any;

  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    try {
      const response = await ai.models.generateContent({
        model: PRIMARY_MODEL,
        contents: [
          { role: 'user', parts: parts }
        ],
        config: {
          systemInstruction: SYSTEM_PROMPT,
          responseMimeType: "application/json",
          responseSchema: RESPONSE_SCHEMA,
          temperature: 0.3,
          safetySettings: safetySettings,
        },
      });

      const cleanedText = cleanJSON(response.text || "");
      if (!cleanedText || cleanedText === "{}") throw new Error("Empty response");
      
      return JSON.parse(cleanedText) as AnalysisResult;

    } catch (error: any) {
      lastError = error;
      if (error.status === 400 || error.status === 403) {
         console.error("API Key or Permission Error:", error);
         throw error;
      }
      const delay = 1000 * (attempt + 1);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  console.error("Analysis Final Failure:", lastError);
  throw new Error(lastError.message || "Analysis failed. Ensure photos are clear and internet is stable.");
};

// ---------------------------------------------------------
// Chatbot Logic
// ---------------------------------------------------------
let chatSession: Chat | null = null;

export const initGenericChat = async () => {
  try {
    const apiKey = getApiKey();
    const ai = new GoogleGenAI({ apiKey });
    
    const systemPrompt = `
      IDENTITY: Beast Bot. 
      STYLE: Helpful, knowledgeable, slightly "alpha" but welcoming.
      ${GLOBAL_CONTEXT}
      
      INSTRUCTIONS: 
      - Provide natural and homemade lookmaxxing advice (e.g., diet, exercises, habits).
      - Do not give complex medical advice.
    `;

    chatSession = ai.chats.create({
      model: CHAT_MODEL, 
      config: { 
        systemInstruction: systemPrompt,
        temperature: 0.5 
      },
    });
  } catch (e) {
    console.warn("Failed to init generic chat:", e);
  }
};

export const initChat = async (contextData: AnalysisResult) => {
  try {
    const apiKey = getApiKey();
    const ai = new GoogleGenAI({ apiKey });
    
    const contextPrompt = `
      IDENTITY: Beast Bot.
      STYLE: Brutal, honest, constructive.
      ${GLOBAL_CONTEXT}
      USER STATS: Score ${contextData.overallScore}.
      USER FLAWS: ${contextData.brutalTruth}.
      
      INSTRUCTIONS:
      - Suggest HOMEMADE and NATURAL routines (Mewing, icing, diet) to fix the user's flaws.
      - Do not jump to surgery suggestions immediately.
      - Keep answers short and actionable.
    `;

    chatSession = ai.chats.create({
      model: CHAT_MODEL, 
      config: { systemInstruction: contextPrompt },
    });
  } catch (e) {
    console.error("Failed to init chat:", e);
    chatSession = null;
    throw e;
  }
};

export const sendMessageToChat = async (msg: string): Promise<string> => {
  if (!chatSession) {
    try {
       await initGenericChat();
       if (!chatSession) throw new Error("Initialization failed");
    } catch {
       throw new Error("Chat not initialized.");
    }
  }
  
  try {
    const result = await chatSession.sendMessage({ message: msg });
    return cleanRepetitiveText(result.text || "...");
  } catch (err: any) {
    if (err.message?.includes("429") || err.status === 429) {
      await new Promise(r => setTimeout(r, 1000));
      try {
         const resultRetry = await chatSession.sendMessage({ message: msg });
         return cleanRepetitiveText(resultRetry.text || "...");
      } catch (e) { return "System busy."; }
    }
    return "Connection failed.";
  }
};
