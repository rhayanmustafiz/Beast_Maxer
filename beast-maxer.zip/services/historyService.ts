
import { ScanHistoryItem, AnalysisResult, QuestionnaireData } from "../types";

const DB_NAME = 'BeastMakerStorage';
const STORE_NAME = 'scans';
const DB_VERSION = 1;

// Helper to open the database
const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = (event) => {
      console.error("Beast Maxer Storage Error:", event);
      reject("Could not open Beast Maxer Storage");
    };

    request.onsuccess = (event) => {
      resolve((event.target as IDBOpenDBRequest).result);
    };

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
};

// Helper to compress image slightly before saving to DB, 
// though IndexedDB can handle large blobs, slight optimization helps performance.
const processImageForStorage = (base64Str: string): Promise<string> => {
  return new Promise((resolve) => {
    // We keep fairly high quality since we have GBs of space now
    resolve(base64Str); 
  });
};

export const getHistory = async (): Promise<ScanHistoryItem[]> => {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll();

      request.onsuccess = () => {
        // Sort by date descending (newest first)
        const results = request.result as ScanHistoryItem[];
        resolve(results.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      };

      request.onerror = () => {
        reject("Failed to retrieve scans from Beast Maxer Storage");
      };
    });
  } catch (e) {
    console.error("Failed to load history", e);
    return [];
  }
};

export const saveScanToHistory = async (
  score: number, 
  originalBase64: string,
  analysisResult: AnalysisResult,
  questionnaireData: QuestionnaireData
): Promise<void> => {
  try {
    const db = await openDB();
    
    // With IndexedDB "Beast Maxer Storage", we can store the full resolution image
    // No need to aggressively compress to thumbnails
    
    const newItem: ScanHistoryItem = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      score,
      thumbnail: originalBase64, // Saving full image as thumbnail for this implementation
      analysisResult,
      questionnaireData
    };

    return new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.add(newItem);

      request.onsuccess = () => {
        console.log("Saved to Beast Maxer Storage successfully.");
        resolve();
      };

      request.onerror = (e) => {
        console.error("Storage write error", e);
        reject("Failed to save to Beast Maxer Storage");
      };
    });
  } catch (error) {
    console.error("Critical storage failure:", error);
  }
};
