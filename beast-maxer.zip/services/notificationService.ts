
export const requestNotificationPermission = async (): Promise<boolean> => {
  if (!("Notification" in window)) {
    console.warn("This browser does not support desktop notifications");
    return false;
  }

  if (Notification.permission === "granted") {
    return true;
  }

  if (Notification.permission !== "denied") {
    const permission = await Notification.requestPermission();
    return permission === "granted";
  }

  return false;
};

export const getPermissionStatus = (): NotificationPermission => {
  if (!("Notification" in window)) return "denied";
  return Notification.permission;
};

export const sendNotification = (title: string, body: string) => {
  if (!("Notification" in window)) return;
  
  if (Notification.permission === "granted") {
    try {
      // Create notification
      // 'vibrate' property is not part of the standard NotificationOptions definition in TypeScript
      // but is supported by some browsers. Casting to any to bypass the check.
      const options: any = {
        body,
        icon: '/logo.png', // Use App Logo
        vibrate: [200, 100, 200],
        tag: 'beast-reminder', // Replaces older notifications with same tag
        renotify: true
      };

      const n = new Notification(title, options);
      
      // Auto close after 5 seconds
      setTimeout(() => n.close(), 5000);
    } catch (e) {
      console.error("Notification failed", e);
    }
  }
};
