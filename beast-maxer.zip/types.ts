
export enum AppStep {
  WELCOME = 'WELCOME',
  AGE_GATE = 'AGE_GATE',
  QUESTIONNAIRE = 'QUESTIONNAIRE',
  UPLOAD_PHOTOS = 'UPLOAD_PHOTOS', // Combined step for Front, Side, Body
  ANALYZING = 'ANALYZING',
  RESULTS = 'RESULTS',
  EXERCISES = 'EXERCISES'
}

export interface QuestionnaireData {
  age: number;
  hairCondition: string;
  posture: string;
  physique: string;
  socialStatus: string;
  datingHistory: string;
  skinType: string;
  sleepQuality: string;
  diet: string;
  waterIntake: string;
}

export interface RoutineItem {
  title: string;
  description: string;
  impact: 'HIGH' | 'MED' | 'LOW';
}

export interface AnalysisResult {
  overallScore: number;
  potentialScore: number;
  
  // New specific metrics (0-100 scale)
  masculinityScore: number;
  skinQualityScore: number;
  jawlineScore: number;
  cheekboneScore: number;
  
  potentialGraph: {
    current: number;
    max: number;
    color: 'RED' | 'YELLOW' | 'GREEN';
  };

  jawlineAnalysis: {
    quality: string;
    flaws: string;
    advice: string;
  };
  
  hairAnalysis: {
    detectedType: string;
    texture: string;
    advice: string;
    recommendedProducts: { type: string, items: string[] } | string[]; // Updated to handle potential object structure or array
  };

  skinAnalysis: {
    texture: string;
    type: string; // e.g. Oily, Combination
    issues: string[];
    fixRoutine: string; // Specific "How to Fix" step-by-step
  };

  bodyAnalysis?: {
    detectedShape: string; // Ectomorph, Mesomorph, etc.
    fatPercentageEstimate: string;
    advice: string;
    workoutFocus: string[]; // Specific muscles to train
  };

  brutalTruth: string;
  assets: string[];
  liabilities: string[];
  
  protocol: RoutineItem[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface ScanHistoryItem {
  id: string;
  date: string;
  score: number;
  thumbnail: string;
  analysisResult: AnalysisResult;
  questionnaireData: QuestionnaireData;
}

export interface Exercise {
  id: number;
  name: string;
  duration: number; // in seconds
  video_url: string; // placeholder for now
  instructions: string;
}
