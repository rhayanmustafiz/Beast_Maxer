
import React, { useState, useEffect } from 'react';
import { AppStep, QuestionnaireData, AnalysisResult, ScanHistoryItem } from './types';
import AgeGate from './components/AgeGate';
import BeastQuestionnaire from './components/BeastQuestionnaire';
import PhotoUpload from './components/PhotoUpload';
import BeastDashboard from './components/BeastDashboard';
import ScanningUI from './components/ScanningUI';
import ExerciseProtocol from './components/ExerciseProtocol';
import WelcomeScreen from './components/WelcomeScreen';
import AdDisplay from './components/AdDisplay';
import BeastChat from './components/BeastChat'; // Import Chat
import { analyzeBeastMode, initChat, initGenericChat } from './services/geminiService';
import { saveScanToHistory } from './services/historyService';
import { playClickSound, playSuccessSound } from './services/audioService';
import { sendNotification } from './services/notificationService';
import { Skull, AlertOctagon, Menu, X, Info, Dumbbell, Download, Copyright, Sun, Moon, WifiOff } from 'lucide-react';

const App: React.FC = () => {
  // Initial state is now WELCOME
  const [step, setStep] = useState<AppStep>(AppStep.WELCOME);
  const [previousStep, setPreviousStep] = useState<AppStep>(AppStep.AGE_GATE);
  const [qData, setQData] = useState<QuestionnaireData | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  // Theme State
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  // Apply Theme to HTML tag
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  // Online Status Listener
  useEffect(() => {
    const handleStatusChange = () => {
      setIsOnline(navigator.onLine);
    };
    window.addEventListener('online', handleStatusChange);
    window.addEventListener('offline', handleStatusChange);
    return () => {
      window.removeEventListener('online', handleStatusChange);
      window.removeEventListener('offline', handleStatusChange);
    };
  }, []);

  // Global Notification Scheduler
  useEffect(() => {
    // Check every minute
    const interval = setInterval(() => {
      const reminders = JSON.parse(localStorage.getItem('beast_reminders') || '[]');
      const waterCount = parseInt(localStorage.getItem('beast_water_count') || '0');
      
      const now = new Date();
      const currentHours = now.getHours().toString().padStart(2, '0');
      const currentMinutes = now.getMinutes().toString().padStart(2, '0');
      const currentTimeString = `${currentHours}:${currentMinutes}`;
      
      // Check for matching reminder time
      if (reminders.includes(currentTimeString)) {
        // If they haven't finished water (less than 8), remind them
        if (waterCount < 8) {
           sendNotification(
             "Hydration Command 💧", 
             "Water gives life. Do not refuse. Do not regress. Make your comeback. 🤝"
           );
        } else {
           // General usage reminder if water is done
           sendNotification(
             "Beast Mode Active", 
             "Hydration complete. Don't forget your daily facial exercises."
           );
        }
      }
    }, 60000); // 60 seconds

    return () => clearInterval(interval);
  }, []);

  // Global Audio Listener: Plays sound on any button click
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      // Check if the clicked element is a button or inside a button
      if (target.tagName === 'BUTTON' || target.closest('button')) {
        playClickSound();
      }
    };
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  // Store images for Scanning UI display
  const [scannedImages, setScannedImages] = useState<{front: string, side: string} | null>(null);

  const handleStartApp = () => {
    setStep(AppStep.AGE_GATE);
    // Initialize generic chat so the bot works immediately
    initGenericChat().catch(e => console.warn("Chat init deferred", e));
  };

  const handleAgeSelect = (age: number) => {
    setQData({
      age,
      hairCondition: '',
      posture: '',
      physique: '',
      socialStatus: '',
      datingHistory: '',
      skinType: '',
      sleepQuality: '',
      diet: '',
      waterIntake: ''
    });
    setStep(AppStep.QUESTIONNAIRE);
  };

  const handleQuestionnaireComplete = (data: QuestionnaireData) => {
    setQData(data);
    setStep(AppStep.UPLOAD_PHOTOS);
  };

  const handleQuestionnaireBack = () => {
    setStep(AppStep.AGE_GATE);
  };

  const handleImagesReady = async (front: string, side: string, body: string | null) => {
    if (!qData) return;
    
    setScannedImages({ front, side });
    setStep(AppStep.ANALYZING);
    setError(null);

    try {
      const result = await analyzeBeastMode(front, side, body, qData);
      
      // Initialize chat with this specific context
      await initChat(result);
      
      // Save to IndexedDB history immediately upon success
      await saveScanToHistory(result.overallScore, front, result, qData);

      setAnalysisResult(result);
      playSuccessSound(); // Play victory sound on result
      setStep(AppStep.RESULTS);
    } catch (err: any) {
      console.error("App Error:", err);
      setError(err.message || "Beast analysis failed. Check connection or try clearer photos.");
      setStep(AppStep.UPLOAD_PHOTOS);
    }
  };

  const handleLoadHistory = async (item: ScanHistoryItem) => {
    try {
      setQData(item.questionnaireData);
      setAnalysisResult(item.analysisResult);
      // When loading history, use the thumbnail as the front image so Dashboard looks good
      setScannedImages({ front: item.thumbnail, side: item.thumbnail }); 
      
      // Re-initialize chat with the loaded context
      await initChat(item.analysisResult);
      setStep(AppStep.RESULTS);
    } catch (e) {
      console.error("Failed to load history item", e);
      setError("Could not load past scan.");
    }
  };

  const handleReset = () => {
    setStep(AppStep.AGE_GATE);
    setQData(null);
    setAnalysisResult(null);
    setScannedImages(null);
    setError(null);
    setIsMenuOpen(false);
    // Re-init generic chat on reset
    initGenericChat().catch(console.warn);
  };

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
    setIsMenuOpen(false); 
  };

  const handleMenuClick = (feature: string) => {
    setIsMenuOpen(false);
    
    if (feature === "About Us") {
      window.location.href = "mailto:beastworldmain@gmail.com?subject=About%20Us&body=we%20wanna%20learn%20about%20you%20more";
      return;
    }

    if (feature === "Exercise Protocols") {
      setPreviousStep(step); // Remember where we came from
      setStep(AppStep.EXERCISES);
      return;
    }

    if (feature === "Get More Apps") {
      // Changed to window.open for more reliable external linking
      window.open("https://t.me/beastworldofficial", "_blank");
      return;
    }

    alert(`[${feature}] - This feature will be available in the next update.`);
  };

  // Online Check Blocker
  if (!isOnline) {
    return (
      <div className="fixed inset-0 z-[9999] bg-black/95 backdrop-blur-xl flex flex-col items-center justify-center p-8 text-center animate-fade-in text-white">
        <WifiOff className="w-20 h-20 text-red-600 mb-6 animate-pulse" />
        <h2 className="text-4xl font-black uppercase tracking-tighter mb-4">Connection Lost</h2>
        <div className="h-1 w-20 bg-red-600 mb-6"></div>
        <p className="text-gray-400 font-mono text-sm max-w-xs leading-relaxed">
          The Beast Protocol requires an active neural link (internet) to access AI models. 
          <br/><br/>
          <span className="text-white font-bold">Please reconnect to proceed.</span>
        </p>
      </div>
    );
  }

  // Dedicated Render for Welcome Screen to overlay everything
  if (step === AppStep.WELCOME) {
    return <WelcomeScreen onStart={handleStartApp} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-beast-bg text-beast-text font-sans bg-grid-pattern bg-[size:40px_40px] transition-colors duration-300">
      
      {/* Header */}
      <header className="border-b border-beast-border bg-beast-bg/80 backdrop-blur-md sticky top-0 z-50 transition-colors">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={handleReset}>
            {/* Header Logo - Refined Display */}
            <img 
              src="./logo.png" 
              alt="Beast Maxer" 
              className="w-12 h-12 object-contain group-hover:scale-110 transition-transform drop-shadow-[0_0_10px_rgba(220,38,38,0.3)]" 
            />
            {/* White Beast, Red Maker (Matches Logo Typography) */}
            <span className="font-black text-lg tracking-tighter uppercase italic">
              <span className="text-beast-text">Beast</span> <span className="text-beast-red group-hover:text-red-400 transition-colors">Maxer</span>
            </span>
          </div>

          <div className="flex items-center gap-4">
            {step === AppStep.RESULTS && (
              <button onClick={handleReset} className="hidden md:block text-xs font-mono text-beast-muted hover:text-beast-text uppercase">
                [ Reset Protocol ]
              </button>
            )}

            {/* Hamburger Menu */}
            <div className="relative">
              <button 
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="p-2 text-beast-text hover:text-beast-red transition-colors"
                aria-label="Menu"
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>

              {/* Dropdown */}
              {isMenuOpen && (
                <div className="absolute right-0 top-12 w-64 bg-beast-card border border-beast-border rounded-xl shadow-2xl overflow-hidden animate-fade-in z-50 ring-1 ring-beast-text/5">
                  <div className="flex flex-col p-2 space-y-1">
                    
                    {/* Theme Toggle */}
                    <button 
                      onClick={toggleTheme}
                      className="flex items-center gap-3 p-3 hover:bg-beast-text/5 rounded-lg text-left text-sm font-medium text-beast-muted hover:text-beast-text transition-all group"
                    >
                      {theme === 'dark' ? (
                        <>
                          <Sun className="w-4 h-4 text-beast-muted group-hover:text-beast-gold" />
                          Light Mode
                        </>
                      ) : (
                        <>
                          <Moon className="w-4 h-4 text-beast-muted group-hover:text-beast-red" />
                          Dark Mode
                        </>
                      )}
                    </button>

                    <div className="h-[1px] bg-beast-border mx-2 my-1"></div>

                    <button 
                      onClick={() => handleMenuClick("About Us")}
                      className="flex items-center gap-3 p-3 hover:bg-beast-text/5 rounded-lg text-left text-sm font-medium text-beast-muted hover:text-beast-text transition-all group"
                    >
                      <Info className="w-4 h-4 text-beast-muted group-hover:text-beast-red" />
                      About Us
                    </button>
                    <button 
                      onClick={() => handleMenuClick("Exercise Protocols")}
                      className="flex items-center gap-3 p-3 hover:bg-beast-text/5 rounded-lg text-left text-sm font-medium text-beast-muted hover:text-beast-text transition-all group"
                    >
                      <Dumbbell className="w-4 h-4 text-beast-muted group-hover:text-beast-red" />
                      Exercises for Perfection
                    </button>
                    <button 
                      onClick={() => handleMenuClick("Get More Apps")}
                      className="flex items-center gap-3 p-3 hover:bg-beast-text/5 rounded-lg text-left text-sm font-medium text-beast-muted hover:text-beast-text transition-all group"
                    >
                      <Download className="w-4 h-4 text-beast-muted group-hover:text-beast-red" />
                      Get More Apps
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 w-full pb-10 relative">
        {error && (
          <div className="max-w-md mx-auto mt-4 p-4 bg-red-900/20 border border-red-500 text-red-400 text-center font-mono text-xs md:text-sm flex items-center gap-2 justify-center animate-pulse">
            <AlertOctagon className="w-5 h-5" />
            <span>[ERROR]: {error}</span>
          </div>
        )}

        {/* Exercises Overlay (Now uses the Full Module) */}
        {step === AppStep.EXERCISES && (
          <ExerciseProtocol onBack={() => setStep(previousStep)} />
        )}
        
        {step === AppStep.AGE_GATE && (
          <AgeGate onSelect={handleAgeSelect} onLoadHistory={handleLoadHistory} />
        )}

        {step === AppStep.QUESTIONNAIRE && qData && (
          <BeastQuestionnaire 
            initialAge={qData.age} 
            onComplete={handleQuestionnaireComplete} 
            onBack={handleQuestionnaireBack}
          />
        )}

        {step === AppStep.UPLOAD_PHOTOS && (
          <PhotoUpload onImagesReady={handleImagesReady} />
        )}

        {step === AppStep.ANALYZING && scannedImages && (
          <ScanningUI frontImage={scannedImages.front} sideImage={scannedImages.side} />
        )}

        {step === AppStep.RESULTS && analysisResult && (
          <BeastDashboard result={analysisResult} userImage={scannedImages?.front} />
        )}
        
        {/* Persistent Chat Bot - Visible on all main screens */}
        <BeastChat />
      </main>

      {/* Footer Area with Ad */}
      <AdDisplay />

      <footer className="w-full py-12 bg-beast-bg/80 backdrop-blur-sm transition-colors">
        <div className="max-w-md mx-auto px-4 flex flex-col items-center justify-center text-center space-y-8">
          <p className="text-[10px] text-beast-muted font-mono uppercase tracking-widest flex items-center justify-center gap-2 hover:text-beast-text transition-colors cursor-default">
             <Copyright className="w-3 h-3" />
             {/* Emerald Green Owner Names */}
             <span>Owned by <span className="text-emerald-500 font-bold">Rhayan</span> & <span className="text-emerald-500 font-bold">Ahasan</span></span>
          </p>
          <p className="text-[9px] text-beast-muted uppercase font-mono leading-relaxed max-w-xs opacity-70 hover:opacity-100 transition-opacity">
            Strict Copyright Disclaimer: No one can copy or report this application. All rights reserved. 
            Unauthorized reproduction is strictly prohibited.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default App;
